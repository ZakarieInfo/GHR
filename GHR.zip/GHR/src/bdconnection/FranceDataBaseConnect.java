package bdconnection;
import java.sql.Connection;
import java.sql.DriverManager;

import config.BdConfig;

/**
 * Point of connection with the Us data source which using the postgreSql RDBMS.
 * 
 * @author Zakarie
 * @version 1.0
 *
 */
public class FranceDataBaseConnect {
	private static String host = BdConfig.FRENCH_HOST_BD ;
	private static String base = BdConfig.FRENCH_BD_NAME;
	private static String user = BdConfig.FRENCH_USER_BD;
	private static String password = BdConfig.FRENCH_PASSWORD_BD;
	private static String url = "jdbc:postgresql://" + host + "/" + base;

	/**
	 * Established the connection with the postgreSql database if this is not already done. 
	 * 
	 * @return an instance of Connection, which is the point of connection with the postgreSql database.
	 */
	private static Connection connection;

	public static Connection getConnection() {
		if (connection == null) {
			try {
				connection = DriverManager.getConnection(url, user, password);
			} catch (Exception e) {
				System.err.println("Connection failed : " + e.getMessage());			
			}
		}
		return connection;
	}
}



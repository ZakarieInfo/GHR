package bdconnection;

import java.sql.Connection;
import java.sql.DriverManager;

import config.BdConfig;

/**
 * Point of connection with the French data source which using the MySQL RDBMS.
 * 
 * @author Zakarie
 * @version 2.0
 *
 */
public class UsaDataBaseConnect {
	private static String host = BdConfig.USA_HOST_BD ;
	private static String base = BdConfig.USA_BD_NAME;
	private static String user = BdConfig.USA_USER_BD;
	private static String password = BdConfig.USA_PASSWORD_BD;
	private static String url = "jdbc:mysql://" + host + "/" + base;

	/**
	 * Singleton instance.
	 */
	private static Connection connection;

	/**
	 * Established the connection with the MySQL database if this is not already done. 
	 * 
	 * @return an instance of Connection, which is the point of connection with MySQL database.
	 */
	public static Connection getConnection() {		
		if (connection == null) {
			try {
				connection = DriverManager.getConnection(url, user, password);
			} catch (Exception e) {
				System.err.println("Connection failed : " + e.getMessage());			
			}
		}
		return connection;
	}
}

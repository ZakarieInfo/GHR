package china;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import data.Absence;
import data.Conge;
import data.Contrat;
import data.Employe;
import mediator.DataToDisplay;



public class ChinaDAO implements DataToDisplay{

	private  ArrayList<Employe> employe = new ArrayList<>();
	private ArrayList <Employe> sup3000 =  new ArrayList<Employe>();
	public ArrayList<String> types = new ArrayList<String>();
	private String averageSalary[][]= new String[3][10];
	private ArrayList <Employe> overtimeEmployees =  new ArrayList<Employe>();
	private ArrayList <Employe> sortEmployeesSalary =  new ArrayList<Employe>();
	private ArrayList <Employe> EmployeesBonusSalary =  new ArrayList<Employe>();
	private double women ;
	private double men;
	private double handicap;
	private ArrayList <Employe> MaxSalaire =  new ArrayList<Employe>();
	private ArrayList <Employe> OldPerson =  new ArrayList<Employe>();
	
	
	private ArrayList <Employe> AbsencesEmploye =  new ArrayList<Employe>();
	
	
	
	public ChinaDAO() {
		super();
	} 
	
	public void extractData() throws JAXBException {
		employe.clear();
		String result = "";
		try {
	            File file = new File(config.BdConfig.CHINA_PATH_FILE);
	            //D:/test.xml
	            FileReader fr = new FileReader(file);
	            BufferedReader br = new BufferedReader(fr);
	            int i=0;
	            String line = "";
	            line=br.readLine();
	            line=br.readLine();
	            line=br.readLine();
	            result ="<employe>";
	            while ((line = br.readLine()) !=null ) {
	            	if("</entreprise>".equals(line.trim()) ){
	            		JAXBContext context;
	            		context = JAXBContext.newInstance(Employe.class); 
	            		Unmarshaller ur = context.createUnmarshaller();
	            		Employe ud = (Employe) ur.unmarshal(new StringReader(result));
	            		 employe.add(ud);
	    	            
	            	}
	            	else if(!("<employe>".equals(line.trim()))) {
	            		result +=line;
	    	         }
	            	else {
	            		
	            		JAXBContext context;
	            		context = JAXBContext.newInstance(Employe.class); 
	            		Unmarshaller ur = context.createUnmarshaller();
	            		Employe ud = (Employe) ur.unmarshal(new StringReader(result));
	            		//System.out.println("unmashalerr = "+ud.toString());
	    	            employe.add(ud);
	    	            result="<employe>";
	            		
	            	}
	            	i++;
	            	
	            }	
	            br.close();
	            
	            
	        } catch (IOException e) {
	            System.out.println("An error occurred.");
	            e.printStackTrace();
	        }
		

	}
	public void AbsencesEmploye() {
		
	}
	public void MaxSalaire(){
		sortEmployeesSalary();
		for(int i =0;i<5;i++) {
			MaxSalaire.add(getSortEmployeesSalary().get(i));
		}
	}
	public void employeesInfo() {
		employe.clear(); 
		try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		for (int i = 0; i < employe.size(); i++) {
			System.out.println(employe.get(i).toString());
			
		}
		
	}
	
	
	public void OldPerson() {
		 try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 int age;
		for (int i = 0; i < employe.size(); i++) {
			age = 2023 - employe.get(i).getDate_de_naissance().getAnnee();
			if(age>= 50) {
				OldPerson.add(employe.get(i));
			}
		}
		
		
	}
	public void women() {
		 try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 double cpt=0;
		 double tot =0;
		for (int i = 0; i < employe.size(); i++) {
			tot=tot+1;
			if(employe.get(i).getSexe().equals("F")) {
				cpt=cpt+1;
			}
		}
		women = cpt/tot*100; 
		
	}
	public void men() {
		 try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 double cpt=0;
		 double tot =0;
		for (int i = 0; i < employe.size(); i++) {
			tot++;
			if(employe.get(i).getSexe().equals("M")) {
				cpt++;
			}
		}
		men = cpt/tot*100;
	
	}
	public void handicap() {
		 try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 double cpt=0;
		 double tot =0;
		for (int i = 0; i < employe.size(); i++) {
			tot++;
			if(employe.get(i).isHandicap()) {
				cpt++;
			}
		}
		handicap = cpt/tot*100;
	
	}
	
	public void Sup3000() {
		 try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		for (int i = 0; i < employe.size(); i++) {
			if(employe.get(i).getSalaire().getMontant_brut()>3000) {
				sup3000.add(employe.get(i));
			}
		}
	}
	public void types() {
		employe.clear();
		 try {
				extractData();
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 for (int i = 0; i < employe.size(); i++) {
				types.add(employe.get(i).getConge().get(1).getMotif());
				types.stream()
                .distinct()
                .collect(Collectors.toList());
				
					
					
					
				}
		}
	
	
	
	
 public void averageSalary(){
	 employe.clear();
	 try {
			extractData();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 int j=0;
	 for (int i = 0; i < employe.size(); i++) {
		if(employe.get(i).getContrat().get(0).getFonction()!= averageSalary[1][i]) {
		
		 
				averageSalary[0][j]=employe.get(i).getContrat().get(0).getSecteur();
				averageSalary[1][j]=employe.get(i).getContrat().get(0).getFonction();
				averageSalary[2][j]=""+employe.get(i).getSalaire().getMontant_brut()+"";
				
				j++;
				
			}
		}
 }


 
 public void overtimeEmployees() {
	 employe.clear();
	 try {
			extractData();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 for (int i = 0; i < employe.size(); i++) {
			if(employe.get(i).getSalaire().getNb_heures_sup()>0) {
				overtimeEmployees.add(employe.get(i));
			}
		}
	 
 }

 
 public void sortEmployeesSalary(){
	 employe.clear();
	 try {
			extractData();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 sortEmployeesSalary = getEmploye();
	 System.out.println(getEmploye().size());
	 int min=0;
	 for (int i = 0; i < sortEmployeesSalary.size(); i++) {
		min=indMax(i) ;
		if(i!=min) {
			permutation(i,min);
		}
	}
	
	 
 }
 
 
 public void permutation(int i, int j) {
	 Employe tmp = sortEmployeesSalary.get(i);
	 sortEmployeesSalary.set(i, sortEmployeesSalary.get(j));
	 sortEmployeesSalary.set(j, tmp);
 }
 public int indMax(int i) {
	    int imax = i;
	    Employe max = sortEmployeesSalary.get(i);
	    for (int j = i + 1; j < sortEmployeesSalary.size(); j++) {
	        if (sortEmployeesSalary.get(j).getSalaire().getMontant_brut() > max.getSalaire().getMontant_brut()) {
	            max = sortEmployeesSalary.get(j);
	            imax = j;
	        }
	    }
	    return imax;
	}

 /*
 public int indMin(int i) {
	 int imin = i;
	 Employe min = sortEmployeesSalary.get(0);
	 for (int j = i; j <sortEmployeesSalary.size(); j++) {
		 
		 if(min.getSalaire().getMontant_brut()<sortEmployeesSalary.get(j).getSalaire().getMontant_brut()) {
			 System.out.println("1");
			 min=sortEmployeesSalary.get(j);
			 imin=j;
			 
		 }
		
	}
	 return imin;
 }
 */

 
 public void EmployeesBonusSalary() {
	 employe.clear();
	 try {
			extractData();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 for (int i = 0; i < employe.size(); i++) {
			if(employe.get(i).getSalaire().getBonus()>0) {
				EmployeesBonusSalary.add(employe.get(i));
			}
		}
	 
 }
 
 
 
 
	public ArrayList<String> getTypes() {
	return types;
}

public void setTypes(ArrayList<String> types) {
	this.types = types;
}

public ArrayList<Employe> getMaxSalaire() {
	return MaxSalaire;
}

public void setMaxSalaire(ArrayList<Employe> maxSalaire) {
	MaxSalaire = maxSalaire;
}

public ArrayList<Employe> getOldPerson() {
	return OldPerson;
}

public void setOldPerson(ArrayList<Employe> oldPerson) {
	OldPerson = oldPerson;
}

public ArrayList<Employe> getAbsencesEmploye() {
	return AbsencesEmploye;
}

public void setAbsencesEmploye(ArrayList<Employe> absencesEmploye) {
	AbsencesEmploye = absencesEmploye;
}

	public double getHandicap() {
	return handicap;
}

public void setHandicap(double handicap) {
	this.handicap = handicap;
}

	public double getWomen() {
	return women;
}

public void setWomen(double women) {
	this.women = women;
}

public double getMen() {
	return men;
}

public void setMen(double men) {
	this.men = men;
}

	public ArrayList<Employe> getEmploye() {
		return employe;
	}

	public void setEmploye(ArrayList<Employe> employe) {
		this.employe = employe;
	}
	
		
	
	public ArrayList<Employe> getSup3000() {
		return sup3000;
	}

	public void setSup3000(ArrayList<Employe> sup3000) {
		this.sup3000 = sup3000;
	}

	public String[][] getAverageSalary() {
		return averageSalary;
	}

	public void setAverageSalary(String[][] averageSalary) {
		this.averageSalary = averageSalary;
	}

	public ArrayList<Employe> getOvertimeEmployees() {
		return overtimeEmployees;
	}

	public void setOvertimeEmployees(ArrayList<Employe> overtimeEmployees) {
		this.overtimeEmployees = overtimeEmployees;
	}

	public ArrayList<Employe> getSortEmployeesSalary() {
		return sortEmployeesSalary;
	}

	public void setSortEmployeesSalary(ArrayList<Employe> sortEmployeesSalary) {
		this.sortEmployeesSalary = sortEmployeesSalary;
	}

	public ArrayList<Employe> getEmployeesBonusSalary() {
		return EmployeesBonusSalary;
	}

	public void setEmployeesBonusSalary(ArrayList<Employe> employeesBonusSalary) {
		EmployeesBonusSalary = employeesBonusSalary;
	}

	@Override
	public String toString() {
		return "ChinaDataDisplay [employe=" + employe + "]";
	}

	
	
	
	
		
		

}

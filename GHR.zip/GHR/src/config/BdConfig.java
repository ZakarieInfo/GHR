package config;

public class BdConfig {
	/**
	 * connexion � la BD mysql (USA)
	 */
	
	public static final String USA_HOST_BD ="mysql-cyliabel.alwaysdata.net";
	
	public static final String USA_USER_BD ="cyliabel";
	
	public static final String USA_BD_NAME ="cyliabel_usa";
	
	public static final String USA_PASSWORD_BD ="Cylia@2001";
	
	/**
	 * connexion � la BD postgres (FRANCE)
	 */
	
	public static final String FRENCH_HOST_BD ="postgresql-rouas.alwaysdata.net";
	
	public static final String FRENCH_USER_BD ="rouas";
	
	public static final String FRENCH_BD_NAME ="rouas_pdi";
	
	public static final String FRENCH_PASSWORD_BD ="lila123lila";
	
	/**
	 * connexion � la BD XML (CHINA)
	 */
	
	public static final String CHINA_PATH_FILE = "D:/lila.xml";
			//"src\\chinaDAO\\BD_XML_chine.xml";
	
	/**
	 * connexion � la BD CSV (CANADA)
	 * 
	 */
	
	public static final String CANADA_PATH_FILE = "src\\chinaDAO\\BD_CSV_canada.csv";
	
}

package config;


public class Request {

	
	public static final String INFO = "1";//Informations sur l'employe
	public static final String SALARY_SUP_3000 = "2";//La liste des employés qui ont un salaire >3000 euro net
	public static final String AVERAGE_SALARY = "3";//Pour chaque secteur de travail, les fonctions et les salaires moyens 
	public static final String OVERTIME_EMPLOYEES = "4";//La liste des employés qui ont fait des heures supplémentaires
	public static final String SORT_EMPLOYEES_SALARY = "5";//Le tri des employé du plus payé au moins payé dans toute les entreprises
	public static final String EMPLOYEES_BONUS_SALARY = "6";//La liste des employés qui ont eu un bonus sur leur salaires
	public static final String CONGE_TYPE = "7";//différents conge
	public static final String POURCENTAGE_H = "8";//  pourcentage des hommes
	public static final String POURCENTAGE_F = "9";//  pourcentage des femmes 
	public static final String EMPLOYE_OVER_60 = "10";// les employes qui ont plus de 60 ans 
	public static final String NUMBER_OVER_60 = "11";// le nombre des employes qui ont plus de 60 ans 
	public static final String MAX_SALAIRE = "12";// Les salaire max de chaque entreprise 
	public static final String ABS_3DAY= "13";// les employ�s qui ont �t� absent plus de  3 jours
	public static final String POURCENTAGE_HD= "14";// le pourcentage des handicap�s
}





package data;

public class Absence {
	private String id_absence ;
	private Date date_abscence;
	private Date date_reprise;
	private String motif_abscence;
	
	
	
	public Absence() {
		super();
	}




	public Absence(String id_absence, Date date_abscence, String motif_abscence) {
		super();
		this.id_absence = id_absence;
		this.date_abscence = date_abscence;
		this.motif_abscence = motif_abscence;
	}




	public Absence(String id_absence, Date date_abscence, Date date_reprise, String motif_abscence) {
		super();
		this.id_absence = id_absence;
		this.date_abscence = date_abscence;
		this.date_reprise = date_reprise;
		this.motif_abscence = motif_abscence;
	}




	public String getId_absence() {
		return id_absence;
	}




	public void setId_absence(String id_absence) {
		this.id_absence = id_absence;
	}




	public Date getDate_abscence() {
		return date_abscence;
	}




	public void setDate_abscence(Date date_abscence) {
		this.date_abscence = date_abscence;
	}




	public Date getDate_reprise() {
		return date_reprise;
	}




	public void setDate_reprise(Date date_reprise) {
		this.date_reprise = date_reprise;
	}




	public String getMotif_abscence() {
		return motif_abscence;
	}




	public void setMotif_abscence(String motif_abscence) {
		this.motif_abscence = motif_abscence;
	}




	
	public String toStringG() {
		return "Absence [id_absence=" + id_absence + ", date_abscence=" + date_abscence + ", date_reprise="
				+ date_reprise + ", motif_abscence=" + motif_abscence + "]";
	}
	@Override
	public String toString() {
		return "Absence: <br/>date_abscence:" + date_abscence + ", date_reprise:"
				+ date_reprise + ", motif_abscence:" + motif_abscence + "<br/>";
	}
	
}

package data;

public class Conge {
	private String id_conge;
	private Date date_debut;
	private Date date_fin;
	private String motif;
	private boolean paye;
	
	
	
	
	public Conge() {
		super();
	}


	public Conge(String id_conge, Date date_debut, Date date_fin, String motif, boolean paye) {
		super();
		this.id_conge = id_conge;
		this.date_debut = date_debut;
		this.date_fin = date_fin;
		this.motif = motif;
		this.paye = paye;
	}
	
	
	public Conge(String id_conge, Date date_debut, Date date_fin) {
		super();
		this.id_conge = id_conge;
		this.date_debut = date_debut;
		this.date_fin = date_fin;
		this.paye=false;
	}
	
	

	public String getId_conge() {
		return id_conge;
	}
	public void setId_conge(String id_conge) {
		this.id_conge = id_conge;
	}
	public Date getDate_debut() {
		return date_debut;
	}
	public void setDate_debut(Date date_debut) {
		this.date_debut = date_debut;
	}
	public Date getDate_fin() {
		return date_fin;
	}
	public void setDate_fin(Date date_fin) {
		this.date_fin = date_fin;
	}
	public String getMotif() {
		return motif;
	}
	public void setMotif(String motif) {
		this.motif = motif;
	}
	public boolean isPaye() {
		return paye;
	}
	public void setPaye(boolean paye) {
		this.paye = paye;
	}


	
	public String toStringG() {
		return "Conge [id_conge=" + id_conge + ", date_debut=" + date_debut + ", date_fin=" + date_fin + ", motif="
				+ motif + ", paye=" + paye + "]";
	}
	@Override
	public String toString() {
		return "Conge: <br/>date_debut="+date_debut +", date_fin="+date_fin+", motif="
				+ motif + ", paye="+paye +"<br/>";
	}
	
	
}

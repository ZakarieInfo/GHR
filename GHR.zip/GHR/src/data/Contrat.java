package data;

public class Contrat {
	private String id_char;
	private String fonction;
	private String statut;
	private Date date_debut;
	private Date date_fin;
	private String secteur;
	
	
	
	public Contrat() {
		super();
	}
	
	

	public Contrat(String id_char, String fonction, Date date_debut, String secteur) {
		super();
		this.id_char = id_char;
		this.fonction = fonction;
		this.date_debut = date_debut;
		this.secteur = secteur;
	}



	public Contrat(String id_char, String fonction, String statut, Date date_debut, Date date_fin, String secteur) {
		super();
		this.id_char = id_char;
		this.fonction = fonction;
		this.statut = statut;
		this.date_debut = date_debut;
		this.date_fin = date_fin;
		this.secteur = secteur;
	}
	
	

	public Contrat(String id_char, String fonction, String statut, Date date_debut, String secteur) {
		super();
		this.id_char = id_char;
		this.fonction = fonction;
		this.statut = statut;
		this.date_debut = date_debut;
		this.secteur = secteur;
	}
	



	public String getId_char() {
		return id_char;
	}

	public void setId_char(String id_char) {
		this.id_char = id_char;
	}

	public String getFonction() {
		return fonction;
	}

	public void setFonction(String fonction) {
		this.fonction = fonction;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	public Date getDate_debut() {
		return date_debut;
	}

	public void setDate_debut(Date date_debut) {
		this.date_debut = date_debut;
	}

	public Date getDate_fin() {
		return date_fin;
	}

	public void setDate_fin(Date date_fin) {
		this.date_fin = date_fin;
	}

	public String getSecteur() {
		return secteur;
	}

	public void setSecteur(String secteur) {
		this.secteur = secteur;
	}

	
	public String toStringG() {
		return "Contrat [id_char=" + id_char + ", fonction=" + fonction + ", statut=" + statut + ", date_debut="
				+ date_debut + ", date_fin=" + date_fin + ", secteur=" + secteur + "]";
	}
	
	public String toStringGUI() {
		return "Contrat [id_char=" + id_char + ", fonction=" + fonction + ", statut=" + statut + ", date_debut="
				+ date_debut + ", date_fin=" + date_fin + ", secteur=" + secteur + "]";
	}
	@Override
	public String toString() {
		return "Contrat: <br/>fonction:" + fonction + ", statut:" + statut + ", date_debut:"
				+ date_debut + ", date_fin:" + date_fin + ", secteur:" + secteur + " <br/>";
	}

	
}

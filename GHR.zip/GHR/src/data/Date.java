package data;

import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Date {
	private int jour = 01;
	private int mois = 01; 
	private int annee = 0000;
	
	
	
	public Date() {
		super();
	}



	public Date(String date) {
	    super();
	    this.jour = Integer.valueOf(date.substring(8, 10));
	    this.mois = Integer.valueOf(date.substring(5,7));
	    this.annee = Integer.valueOf(date.substring(0,4));
	}
/*
	public Datee(String date) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Datee dateObj = format.parse(date);
        this.jour = dateObj.getDate();
        this.mois = dateObj.getMonth() + 1;
        this.annee = dateObj.getJour() + 1900;
    }
*/
	public Date(int jour, int mois, int annee) {
		super();
		this.jour = jour;
		this.mois = mois;
		this.annee = annee;
	}
	
	

	public int getJour() {
		return jour;
	}



	public void setJour(int jour) {
		this.jour = jour;
	}



	public int getMois() {
		return mois;
	}



	public void setMois(int mois) {
		this.mois = mois;
	}



	public int getAnnee() {
		return annee;
	}



	public void setAnnee(int annee) {
		this.annee = annee;
	}



	
	public String toStringG() {
		return "Date [jour=" + jour + ", mois=" + mois + ", annee=" + annee + "]";
	}
	
	
	public String toString2() {
		return "Date:" + jour + "/" + mois + "/" + annee + "";
	}
	
	public String toString() {
		return " " + jour + "/" + mois + "/" + annee + " ";
	}
}



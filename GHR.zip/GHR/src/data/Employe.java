package data;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement 	
@XmlAccessorType(XmlAccessType.FIELD)
public class Employe {
	private String id_employe;
	private String nom_employe;
	private String prenom_employe;
	private String ville;
	private String telephone;
	private String mail;
	private Date dateEmbauche;
	private Date date_de_naissance;
	private boolean handicap;
	private String sexe;
	private ArrayList<Absence>  absence;
	private ArrayList<Conge>  conge;
	private ArrayList<Contrat>  contrat;
	private Salaire salaire;
	
	
	
	public Employe() {
		super();
	}

	public Employe(String id_employe2, String nom_employe2, String prenom_employe2, String ville2, String sexe2, String mail2, Date dateEmbauche2, Date date_de_naissance2, boolean handicape) {
		super();
		this.id_employe = id_employe2;
		this.nom_employe = nom_employe2;
		this.prenom_employe = prenom_employe2;
		this.ville = ville2;
		
		this.mail = mail2;
		this.dateEmbauche = dateEmbauche2;
		this.date_de_naissance = date_de_naissance2;
		this.handicap = handicape;
		this.sexe = sexe2;
	}

	public Employe(String id_employe, String nom_employe, String prenom_employe, String ville, String telephone,
			String mail, Date dateEmbauche, Date date_de_naissance, boolean handicap, String sexe) {
		super();
		this.id_employe = id_employe;
		this.nom_employe = nom_employe;
		this.prenom_employe = prenom_employe;
		this.ville = ville;
		this.telephone = telephone;
		this.mail = mail;
		this.dateEmbauche = dateEmbauche;
		this.date_de_naissance = date_de_naissance;
		this.handicap = handicap;
		this.sexe = sexe;
	}

	public Employe(String id_employe, String nom_employe, String prenom_employe, String mail, Date date_de_naissance) {
		super();
		this.id_employe = id_employe;
		this.nom_employe = nom_employe;
		this.prenom_employe = prenom_employe;
		this.mail = mail;
		this.date_de_naissance = date_de_naissance;
	}

	public String getId_employe() {
		return id_employe;
	}

	public void setId_employe(String id_employe) {
		this.id_employe = id_employe;
	}

	public String getNom_employe() {
		return nom_employe;
	}

	public void setNom_employe(String nom_employe) {
		this.nom_employe = nom_employe;
	}

	public String getPrenom_employe() {
		return prenom_employe;
	}

	public void setPrenom_employe(String prenom_employe) {
		this.prenom_employe = prenom_employe;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public Date getDateEmbauche() {
		return dateEmbauche;
	}

	public void setDateEmbauche(Date dateEmbauche) {
		this.dateEmbauche = dateEmbauche;
	}

	public Date getDate_de_naissance() {
		return date_de_naissance;
	}

	public void setDate_de_naissance(Date date_de_naissance) {
		this.date_de_naissance = date_de_naissance;
	}

	public boolean isHandicap() {
		return handicap;
	}

	public void setHandicap(boolean handicap) {
		this.handicap = handicap;
	}

	public String getSexe() {
		return sexe;
	}

	public void setSexe(String sexe) {
		this.sexe = sexe;
	}

	public ArrayList<Absence> getAbsence() {
		return absence;
	}

	public void setAbsence(ArrayList<Absence> absence) {
		this.absence = absence;
	}

	public ArrayList<Conge> getConge() {
		return conge;
	}

	public void setConge(ArrayList<Conge> conge) {
		this.conge = conge;
	}

	public ArrayList<Contrat> getContrat() {
		return contrat;
	}

	public void setContrat(ArrayList<Contrat> contrat) {
		this.contrat = contrat;
	}

	public Salaire getSalaire() {
		return salaire;
	}

	public void setSalaire(Salaire salaire) {
		this.salaire = salaire;
	}
	public void addContrat(Contrat c) {
		this.contrat.add(c);
	}
	
	
	
	public String toStringAll() {
		return "Employe [id_employe=" + id_employe + ", nom_employe=" + nom_employe + ", prenom_employe="
				+ prenom_employe + ", ville=" + ville + ", telephone=" + telephone + ", mail=" + mail
				+ ", dateEmbauche=" + dateEmbauche + ", date_de_naissance=" + date_de_naissance + ", handicap="
				+ handicap + ", sexe=" + sexe + ", absence=" + absence + ", conge=" + conge + ", contrat=" + contrat
				+ ", salaire=" + salaire + "]";
	}

	
	public String toStringG() {
		return  "nom_employe=" + nom_employe + ",\n prenom_employe="
				+ prenom_employe + ",\n ville=" + ville + ",\n telephone=" + telephone + ",\n mail=" + mail
				+ ",\n dateEmbauche=" + dateEmbauche + ",\n date_de_naissance=" + date_de_naissance + ",\n handicap="
				+ handicap + ",\n sexe=" + sexe+"" ;
	}
	public String toStringGui() {
		return "<html>Employe [id_employe=" + id_employe + ", nom_employe=" + nom_employe + ", prenom_employe="
				+ prenom_employe + ", ville=" + ville + ", telephone=" + telephone + ", mail=" + mail
				+ ",<br/> dateEmbauche=" + dateEmbauche + ", date_de_naissance=" + date_de_naissance + ", handicap="
				+ handicap + ", sexe=" + sexe + ", absence=" + absence + ",<br/> conge=" + conge + ",<br/> contrat=" + contrat
				+ ",<br/> salaire=" + salaire + "]<br/></html>";
	}
	@Override
	public String toString() {
		return "Employe: <br/>nom_employe:" + nom_employe + ", prenom_employe:"
				+ prenom_employe + ", ville:" + ville + ", telephone:" + telephone + ", mail:" + mail
				+ ", dateEmbauche:" + dateEmbauche + ", date_de_naissance:" + date_de_naissance + ", handicap:"
				+ handicap + ", sexe:" + sexe + ", absence:<br/>" + absence + ", conge:<br/>" + conge + ", contrat:<br/>" + contrat
				+ ", salaire:<br/>" + salaire + "";
	}
	/*public String toString() {
		return "\n---------------\nEmploye : \nid_employe=" + id_employe + ",\n nom_employe=" + nom_employe + ",\n prenom_employe="
				+ prenom_employe + ",\n ville=" + ville + ",\n telephone=" + telephone + ",\n mail=" + mail
				+ ",\n dateEmbauche=" + dateEmbauche + ",\n date_de_naissance=" + date_de_naissance + ",\n handicap="
				+ handicap + ",\n sexe=" + sexe ;
	}
	*/
	
	
	
	
	
	
	
	
}

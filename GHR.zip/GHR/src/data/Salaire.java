package data;

public class Salaire {
	private String id_salaire;
	private Date date_paiement;
	private float montant_net;
	private float montant_brut;
	private float bonus;
	private float nb_heures_tot;
	private float nb_heures_sup;
	
	
	public Salaire() {
		super();
	}
	public Salaire(String id_salaire, Date date_paiement, float montant_net, float montant_brut, float bonus,
			float nb_heures_tot, float nb_heures_sup) {
		super();
		this.id_salaire = id_salaire;
		this.date_paiement = date_paiement;
		this.montant_net = montant_net;
		this.montant_brut = montant_brut;
		this.bonus = bonus;
		this.nb_heures_tot = nb_heures_tot;
		this.nb_heures_sup = nb_heures_sup;
	}
	public Salaire(String id_salaire, float montant_net, float montant_brut, float bonus,
			float nb_heures_tot, float nb_heures_sup) {
		super();
		this.id_salaire = id_salaire;
		this.date_paiement = date_paiement;
		this.montant_net = montant_net;
		this.montant_brut = montant_brut;
		this.bonus = bonus;
		this.nb_heures_tot = nb_heures_tot;
		this.nb_heures_sup = nb_heures_sup;
	}
	public Salaire(String id_salaire, float montant_brut, float bonus,
			float nb_heures_tot, float nb_heures_sup) {
		super();
		this.id_salaire = id_salaire;
		
		this.montant_brut = montant_brut;
		this.bonus = bonus;
		this.nb_heures_tot = nb_heures_tot;
		this.nb_heures_sup = nb_heures_sup;
	}
	public String getId_salaire() {
		return id_salaire;
	}
	public void setId_salaire(String id_salaire) {
		this.id_salaire = id_salaire;
	}
	public Date getDate_paiement() {
		return date_paiement;
	}
	public void setDate_paiement(Date date_paiement) {
		this.date_paiement = date_paiement;
	}
	public float getMontant_net() {
		return montant_net;
	}
	public void setMontant_net(float montant_net) {
		this.montant_net = montant_net;
	}
	public float getMontant_brut() {
		return montant_brut;
	}
	public void setMontant_brut(float montant_brut) {
		this.montant_brut = montant_brut;
	}
	public float getBonus() {
		return bonus;
	}
	public void setBonus(float bonus) {
		this.bonus = bonus;
	}
	public float getNb_heures_tot() {
		return nb_heures_tot;
	}
	public void setNb_heures_tot(float nb_heures_tot) {
		this.nb_heures_tot = nb_heures_tot;
	}
	public float getNb_heures_sup() {
		return nb_heures_sup;
	}
	public void setNb_heures_sup(float nb_heures_sup) {
		this.nb_heures_sup = nb_heures_sup;
	}
	
	public String toStringG() {
		return "Salaire [id_salaire=" + id_salaire + ", date_paiement=" + date_paiement + ", montant_net=" + montant_net
				+ ", montant_brut=" + montant_brut + ", bonus=" + bonus + ", nb_heures_tot=" + nb_heures_tot
				+ ", nb_heures_sup=" + nb_heures_sup + "]";
	}
	@Override
	public String toString() {
		return "Salaire: date_paiement:"+date_paiement +", montant_net:"+montant_net
				+ ", montant_brut:"+montant_brut+", bonus="+bonus+", nb_heures_tot:"+nb_heures_tot
				+ ", nb_heures_sup:"+ nb_heures_sup +"<br/>";
	}
	
}

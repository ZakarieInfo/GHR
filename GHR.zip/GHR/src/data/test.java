package data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;



public class test {

	private static ArrayList<Employe> employe;

	public static void main(String[] args) throws JAXBException {
		employe =new ArrayList<>();
		String result = "";
		try {
	            File file = new File("D:/test.xml");
	            FileReader fr = new FileReader(file);
	            BufferedReader br = new BufferedReader(fr);
	            
	            String line = "";
	            line=br.readLine();
	            line=br.readLine();
	            line=br.readLine();
	            result ="<employe>";
	            while ((line = br.readLine()) !=null ) {
	            	if("</entreprise>".equals(line.trim()) ){
	            		JAXBContext context;
	            		context = JAXBContext.newInstance(Employe.class); 
	            		Unmarshaller ur = context.createUnmarshaller();
	            		Employe ud = (Employe) ur.unmarshal(new StringReader(result));
	            		 employe.add(ud);
	    	            
	            	}
	            	else if(!("<employe>".equals(line.trim()))) {
	            		result +=line;
	    	         }
	            	else {
	            		
	            		JAXBContext context;
	            		context = JAXBContext.newInstance(Employe.class); 
	            		Unmarshaller ur = context.createUnmarshaller();
	            		Employe ud = (Employe) ur.unmarshal(new StringReader(result));
	            		//System.out.println("unmashalerr = "+ud.toString());
	    	            employe.add(ud);
	    	            result="<employe>";
	            		
	            	}
	            
	            	
	            }	
	            br.close();
	            
	            
	        } catch (IOException e) {
	            System.out.println("An error occurred.");
	            e.printStackTrace();
	        }
		
	//System.out.println(employe.get(0));
	//System.out.println(employe.get(1));
	//System.out.println(employe.get(2));
		

	}

}

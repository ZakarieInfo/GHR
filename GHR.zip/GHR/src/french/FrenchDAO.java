package french;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bdconnection.FranceDataBaseConnect;
import bdconnection.UsaDataBaseConnect;
import data.Absence;
import data.Conge;
import data.Contrat;
import data.Date;
import data.Employe;
import data.Salaire;
import mediator.DataToDisplay;


/**
 * This class manage all the recovery of the data from the Us DataBase 
 * 
 * @author Paul
 * @version 3.0
 * 
 */
public class FrenchDAO implements DataToDisplay{
	private FranceDataBaseConnect  dtf;
	private ArrayList <Employe> employeeInfo =  new ArrayList<Employe>();
	private ArrayList <Employe> sup3000 =  new ArrayList<Employe>();
	private String averageSalary[][]= new String[3][10];
	private ArrayList <Employe> overtimeEmployees =  new ArrayList<Employe>();
	private ArrayList <Employe> sortEmployeesSalary =  new ArrayList<Employe>();
	private ArrayList <Employe> EmployeesBonusSalary =  new ArrayList<Employe>();
	private ArrayList <Employe> AbsencesEmploye =  new ArrayList<Employe>();
	private ArrayList <Employe> MaxSalaire =  new ArrayList<Employe>();
	private ArrayList <Employe> OldPerson=  new ArrayList<Employe>();
	private ArrayList<Conge>  conge = new ArrayList<Conge>();
	private ArrayList<Contrat>  contrat = new ArrayList<Contrat>();
	private ArrayList<Absence>  absence = new ArrayList<Absence>();
	public ArrayList<String> types = new ArrayList<String>();
	private Salaire salaire;
	 Map<String, Integer> counts = new HashMap<>();
	/**
	 * This constructor search the number of employees by status
	 * 
	 */
	public FrenchDAO() {
		/*try {
			Connection dbConnection = dtb.getConnection();
			//Statement statement = dbConnection.createStatement();
			ResultSet result;
			result = statement.executeQuery("SELECT statut, COUNT(statut) FROM employe AS e INNER JOIN "
					+ "contrat AS c ON e.matricule = c.matricule GROUP BY statut");
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
 	
	public Map<String, Integer> countCongesByType() throws SQLException {
		Connection dbConnection = dtf.getConnection();
		 Statement stmt = dbConnection.createStatement();
	    String sql = "SELECT motif, COUNT(*) AS repetition\r\n"
	    		+ "FROM \"public\".\"Conge\"\r\n"
	    		+ "GROUP BY motif;";
	    ResultSet rs = stmt.executeQuery(sql);
	        
	        while (rs.next()) {
	            String type = rs.getString("motif");
	            int count = rs.getInt("repetition");
	            counts.put(type, count);
	        }
	    
	    return counts;
	}

	/**
	 * Get a list of EmployeUs.
	 *  
	 * @return a list of EmployeUs
	 */
	public void employeesInfo(){
		String id_employe;
		String nom_employe;
		String prenom_employe;
		String ville;
		String telephone;
		String mail;
		Date dateEmbauche;
		Date date_de_naissance;
		boolean handicap;
		String sexe;
		Employe employe=null;
		String request = "SELECT * FROM \"public\".\"Employe\";";
		Connection dbConnection = FranceDataBaseConnect.getConnection();
		
		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			while (result.next()) {
			
				id_employe=result.getString("id_employe");
				nom_employe=result.getString("nom_employe");
				prenom_employe=result.getString("prenom_employe");
				telephone=result.getString("telephone");
				ville=result.getString("ville");
				sexe= result.getString("sexe");
				mail=result.getString("mail");
				dateEmbauche=new Date(result.getString("dateEmbauche")) ;
				date_de_naissance= new Date(result.getString("date_naissance"));
				handicap=result.getBoolean("handicape");
				employe = new Employe(id_employe,nom_employe,prenom_employe,ville,telephone,mail,dateEmbauche,date_de_naissance,handicap,sexe);
				employeeInfo.add(employe);
				
				Info(employeeInfo);
				//employe=Info(employe);
				
				
				/* absence.clear();
				 contrat.clear();
				 absence.clear();
				 contrat.clear();*/
			}
			preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		
	}
	
	public void Info(String idEmploye, String typeObject){

		/*String request = "SELECT *FROM\"public\".\""+typeObject+"\" WHERE id_employe="+idEmploye+";";
		Connection dbConnection = FranceDataBaseConnect.getConnection();
		
		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			while (result.next()) {
				if(typeObject == "Salaire " )
				
				employeesInfo.add(employe);
			}
			preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		*/
	}
	
	
	public void Sup3000(){
		String id_employe;
		String nom_employe;
		String prenom_employe;
		String ville;
		String telephone;
		String mail;
		Date dateEmbauche;
		Date date_de_naissance;
		boolean handicap;
		String sexe;
		Employe employe=null;
		String request = "SELECT *FROM \"public\".\"Employe\" NATURAL JOIN\"public\".\"Salaire\" WHERE montant_net>3000;";
		Connection dbConnection = FranceDataBaseConnect.getConnection();

		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			while (result.next()) {
				id_employe=result.getString("id_employe");
				nom_employe=result.getString("nom_employe");
				prenom_employe=result.getString("prenom_employe");
				telephone=result.getString("telephone");
				ville=result.getString("ville");
				sexe= result.getString("sexe");
				mail=result.getString("mail");
				dateEmbauche=new Date(result.getString("dateEmbauche")) ;
				date_de_naissance= new Date(result.getString("date_naissance"));
				handicap=result.getBoolean("handicape");
				employe = new Employe(id_employe,nom_employe,prenom_employe,ville,telephone,mail,dateEmbauche,date_de_naissance,handicap,sexe);
				//System.out.println(employe.toString());
				sup3000.add(employe);
				Info(sup3000);
			}
			preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		
	}
	/*
	#â€¢ La liste des employÃ©s qui ont fait des heures supplÃ©mentaires
	SELECT *FROM ("public"."Employe" NATURAL JOIN"public"."Salaire") WHERE nb_heures_sup>0;

	    #â€¢ Le tri des employÃ© du plus payÃ© au moins payÃ© dans toute les entreprises
	SELECT *FROM("public"."Employe" NATURAL JOIN "public"."Salaire") ORDER BY montant_brut DESC;

	    #â€¢ La liste des employÃ©s qui ont eu un bonus sur leur salaires
	SELECT *FROM ("public"."Employe" NATURAL JOIN"public"."Salaire") WHERE bonus>0;
*/

	public void averageSalary(){
		
		int i=0;
		String request = "SELECT secteur,fonction, AVG(montant_net) as montant_brut FROM (\"public\".\"Contrat\" NATURAL JOIN \"public\".\"Employe\" NATURAL JOIN \"public\".\"Salaire\") GROUP BY secteur,fonction;";
		Connection dbConnection = FranceDataBaseConnect.getConnection();

		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			
			while (result.next()&& i<10) {
				 
				
				averageSalary[0][i]=result.getString("secteur");
				averageSalary[1][i]=result.getString("fonction");
				averageSalary[2][i]=result.getString("montant_brut");
				System.out.println(averageSalary[0][i]+" "+averageSalary[1][i]+" "+averageSalary[2][i] );
				i++;
				
			}
			//preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		
	}
	
	public void overtimeEmployees(){
		String id_employe;
		String nom_employe;
		String prenom_employe;
		String ville;
		String telephone;
		String mail;
		Date dateEmbauche;
		Date date_de_naissance;
		boolean handicap;
		String sexe;
		Employe employe=null;
		String request = "SELECT *FROM \"public\".\"Employe\" NATURAL JOIN\"public\".\"Salaire\" WHERE nb_heures_sup>0;";
		Connection dbConnection = FranceDataBaseConnect.getConnection();

		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			while (result.next()) {
				id_employe=result.getString("id_employe");
				nom_employe=result.getString("nom_employe");
				prenom_employe=result.getString("prenom_employe");
				telephone=result.getString("telephone");
				ville=result.getString("ville");
				sexe= result.getString("sexe");
				mail=result.getString("mail");
				dateEmbauche=new Date(result.getString("dateEmbauche")) ;
				date_de_naissance= new Date(result.getString("date_naissance"));
				handicap=result.getBoolean("handicape");
				employe = new Employe(id_employe,nom_employe,prenom_employe,ville,telephone,mail,dateEmbauche,date_de_naissance,handicap,sexe);
				
				overtimeEmployees.add(employe);
				Info(overtimeEmployees);
			}
			preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		
	}
	
	public void sortEmployeesSalary(){
		String id_employe;
		String nom_employe;
		String prenom_employe;
		String ville;
		String telephone;
		String mail;
		Date dateEmbauche;
		Date date_de_naissance;
		boolean handicap;
		String sexe;
		Employe employe=null;
		String request = "SELECT *FROM\"public\".\"Employe\" NATURAL JOIN \"public\".\"Salaire\" ORDER BY montant_brut DESC;";
		Connection dbConnection = FranceDataBaseConnect.getConnection();

		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			while (result.next()) {
				id_employe=result.getString("id_employe");
				nom_employe=result.getString("nom_employe");
				prenom_employe=result.getString("prenom_employe");
				telephone=result.getString("telephone");
				ville=result.getString("ville");
				sexe= result.getString("sexe");
				mail=result.getString("mail");
				dateEmbauche=new Date(result.getString("dateEmbauche")) ;
				date_de_naissance= new Date(result.getString("date_naissance"));
				handicap=result.getBoolean("handicape");
				employe = new Employe(id_employe,nom_employe,prenom_employe,ville,telephone,mail,dateEmbauche,date_de_naissance,handicap,sexe);
				
				sortEmployeesSalary.add(employe);
				Info(sortEmployeesSalary);
			}
			preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		
	}
	
	
	public void EmployeesBonusSalary(){
		String id_employe;
		String nom_employe;
		String prenom_employe;
		String ville;
		String telephone;
		String mail;
		Date dateEmbauche;
		Date date_de_naissance;
		boolean handicap;
		String sexe;
		Employe employe=null;
		String request = "SELECT *FROM (\"public\".\"Employe\" NATURAL JOIN\"public\".\"Salaire\") WHERE bonus>0;";
		Connection dbConnection = FranceDataBaseConnect.getConnection();

		try {
			PreparedStatement preparedStatement = dbConnection.prepareStatement(request);
			ResultSet result = preparedStatement.executeQuery();
			while (result.next()) {
				id_employe=result.getString("id_employe");
				nom_employe=result.getString("nom_employe");
				prenom_employe=result.getString("prenom_employe");
				telephone=result.getString("telephone");
				ville=result.getString("ville");
				sexe= result.getString("sexe");
				mail=result.getString("mail");
				dateEmbauche=new Date(result.getString("dateEmbauche")) ;
				date_de_naissance= new Date(result.getString("date_naissance"));
				handicap=result.getBoolean("handicape");
				employe = new Employe(id_employe,nom_employe,prenom_employe,ville,telephone,mail,dateEmbauche,date_de_naissance,handicap,sexe);
				
				EmployeesBonusSalary.add(employe);
				Info(EmployeesBonusSalary);
			}
			preparedStatement.close();
		} catch(SQLException se) {
			se.getMessage();
		}
		
	}
	
	
	
	/*"SELECT COUNT( CASE WHEN sexe ='F' THEN 1 END) * 100.0 / COUNT(*) AS pourcentage_femmes FROM "public"."Employe""; */

	
	public double pourcentageFemmes() throws SQLException {
		 Connection dbConnection = FranceDataBaseConnect.getConnection();
			//Statement statement = dbConnection.createStatement();
			 Statement stmt = dbConnection.createStatement();
			  String sql = "SELECT COUNT( CASE WHEN sexe ='F' THEN 1 END) * 100.0 / COUNT(*) AS pourcentage_femmes FROM \"public\".\"Employe\"";
			   ResultSet rs = stmt.executeQuery(sql);
				 double pourcentage = 0;
			            rs.next();
			            pourcentage = rs.getDouble("pourcentage_femmes");
			            //dbConnection.close();
			      
			        return pourcentage;
			    }
	
	
	
	 public double pourcentageHommes() throws SQLException {
		 Connection dbConnection = dtf.getConnection();
			//Statement statement = dbConnection.createStatement();
			 Statement stmt = dbConnection.createStatement();
			 String sql = "SELECT COUNT( CASE WHEN sexe ='H' THEN 1 END) * 100.0 / COUNT(*) AS pourcentage_hommes FROM \"public\".\"Employe\"";
		     ResultSet rs = stmt.executeQuery(sql);
		     double pourcentage = 0;
	            rs.next();
	            
	            pourcentage = rs.getDouble("pourcentage_hommes");
	            //dbConnection.close();
	      
	           return pourcentage;
	    }

	 public double PourcentageHandicapes() throws SQLException {
		    Connection dbConnection = dtf.getConnection();
			//Statement statement = dbConnection.createStatement();
			 Statement stmt = dbConnection.createStatement();
			 String sql = "SELECT COUNT( CASE WHEN handicape ='TRUE' THEN 1 END) * 100.0 / COUNT(*) AS handicape FROM \"public\".\"Employe\"";
		     ResultSet rs = stmt.executeQuery(sql);
		     double pourcentage = 0;
		     if (rs.next()) {
		         pourcentage = rs.getDouble("handicape");
		       }
		      /* if (rs != null) {
		         rs.close();
		       }
		       if (stmt != null) {
		         stmt.close();
		       }
		       if ( dbConnection!= null) {
		    	   dbConnection.close();
		       }*/
		     return pourcentage;
		   }
	 
	 
	 public void EmployesAbsentsPlusDeTroisJours() throws SQLException {
		    Connection dbConnection = dtf.getConnection();
			//Statement statement = dbConnection.createStatement();
			 Statement stmt = dbConnection.createStatement();
			 String sql = "SELECT e.*\r\n"
			 		+ "FROM \"public\".\"Employe\" e\r\n"
			 		+ "INNER JOIN \"public\".\"Absence\" a ON e.id_employe = a.id_employe\r\n"
			 		+ "WHERE extract(day from age(a.date_reprise, a.date_absence)) > 3;" ;
		     ResultSet rs = stmt.executeQuery(sql);
		     while (rs.next()) {
		            Employe employe = new Employe();
		            employe.setId_employe(rs.getString("id_employe"));
		            employe.setNom_employe(rs.getString("nom_employe"));
		            employe.setPrenom_employe(rs.getString("prenom_employe"));
		            employe.setSexe(rs.getString("sexe"));
		            employe.setTelephone(rs.getString("telephone"));
		            employe.setMail(rs.getString("mail"));
		            employe.setVille(rs.getString("ville"));
		            
		            employe.setDate_de_naissance(new Date());
		            //employe.setSalaire(rs.getDouble("salaire"));
		            AbsencesEmploye.add(employe);
		            Info(AbsencesEmploye);
		        }
		      // dbConnection.close();
		    
		  
	 }  
	 
	 
	 public void EmployesWithMaxSalaire() throws SQLException {
		    Connection dbConnection = dtf.getConnection();
		    Statement stmt = dbConnection.createStatement();
		    String sql = "SELECT \"Employe\".*, \"Salaire\".*, MAX(\"Salaire\".montant_brut) AS salaire_brut_maximal \r\n"
		    		+ "FROM public.\"Employe\"\r\n"
		    		+ "JOIN public.\"Salaire\" ON \"Employe\".id_employe = \"Salaire\".id_employe \r\n"
		    		+ "GROUP BY \"Employe\".id_employe, \"Salaire\".id_salaire\r\n"
		    		+ "ORDER BY salaire_brut_maximal DESC \r\n"
		    		+ "LIMIT 6;";
		    ResultSet rs = stmt.executeQuery(sql);
		    while (rs.next()) {
		    	Employe employe = new Employe();
	            employe.setId_employe(rs.getString("id_employe"));
	            employe.setNom_employe(rs.getString("nom_employe"));
	            employe.setPrenom_employe(rs.getString("prenom_employe"));
	            employe.setSexe(rs.getString("sexe"));
	            employe.setTelephone(rs.getString("telephone"));
	            employe.setMail(rs.getString("mail"));
	            employe.setVille(rs.getString("ville"));
		        MaxSalaire.add(employe);
		        Info(MaxSalaire);
		    }
		   // dbConnection.close();
		  
		}

	 
	 public int NumberEmployeesOver60() throws SQLException {
		
		    Connection dbConnection = dtf.getConnection();
		    Statement stmt = dbConnection.createStatement();
		    String sql = "SELECT COUNT(*) AS total FROM \"public\".\"Employe\" WHERE date_naissance <= (NOW() - INTERVAL '60 years')";
		    ResultSet rs = stmt.executeQuery(sql);
		    int numberOfEmployees = 0;
		    while (rs.next()) {
		        numberOfEmployees = rs.getInt("total");
		    }
		    rs.close();
		    stmt.close();
		    dbConnection.close();
		    return numberOfEmployees;
		}
   
	 public void EmployeesOver60() throws SQLException {
		    Connection dbConnection = dtf.getConnection();
			//Statement statement = dbConnection.createStatement();
			 Statement stmt = dbConnection.createStatement();
			 String sql = "SELECT * FROM \"public\".\"Employe\" WHERE date_naissance <= (NOW() - INTERVAL '50 years')";
		     ResultSet rs = stmt.executeQuery(sql);
		     while (rs.next()) {
		    	    String id_employe = rs.getString("id_employe");
				    String nom = rs.getString("nom_employe");
					
					String prenom = rs.getString("prenom_employe");
					
					String ville = rs.getString("ville");
					
					String telephone = rs.getString("telephone");
					
					String mail = rs.getString("mail");
					Date dateEmbauche = new Date(rs.getString("dateEmbauche"));
				
					Date dateDeNaissance = new Date(rs.getString("date_naissance"));
					
					boolean handicap = rs.getBoolean("handicape");
					String sexe = rs.getString("sexe");
					Employe emp = new Employe(id_employe,nom, prenom, ville, telephone, mail, dateEmbauche, dateDeNaissance, handicap, sexe);
		         OldPerson.add(emp);
		         Info(OldPerson);
		     }

		     //rs.close();
		    // stmt.close();
		     //dbConnection.close();
	    }
	 public void searchAttribute(String id,String object,Employe e) throws SQLException{
		 
			//conge.clear();
			//absence.clear();
			//contrat.clear();
		    String request = "SELECT * FROM  \"public\".\"" + object + "\" WHERE id_employe=" + id + ";";
			Connection dbConnection = dtf.getConnection();
			PreparedStatement stmt = dbConnection.prepareStatement(request);
			ResultSet result = stmt.executeQuery();
			
			while (result.next()) {
			if(object.equals("Salaire")) {
				String id_salaire;
				float montant_net;
				float montant_brut;
				float bonus;
				float nb_heures_tot;
				float nb_heures_sup;
				id_salaire = result.getString("id_salaire");
				montant_brut=result.getFloat("montant_brut");
				montant_net=result.getFloat("montant_net");
				bonus=result.getFloat("bonus");
				nb_heures_tot=result.getFloat("nb_heures_tot");
				nb_heures_sup=result.getFloat("nb_heures_sup");
				
				Salaire s = new Salaire(id_salaire,montant_net,montant_brut,bonus, nb_heures_tot, nb_heures_sup);
				salaire = s;
				e.setSalaire(s);
			}
			else if(object.equals("Absence")) {
				
				String id_absence ;
				Date date_abscence;
				Date date_reprise;
				String motif_abscence;
				
				id_absence =result.getString("id_absence");
				date_abscence= new Date(result.getString("date_absence")) ;
				date_reprise= new Date(result.getString("date_reprise")) ;
				motif_abscence=result.getString("motif_absence");
				
				Absence a= new Absence(id_absence,date_abscence,date_reprise, motif_abscence);
				
				ArrayList<Absence> lc = new ArrayList<Absence>();
				lc.add(a);	
				e.setAbsence(lc);
			}
			else if(object.equals("Conge")) {
				String id_conge;
				Date date_debut;
				Date date_fin;
				String motif;
				boolean paye;
				
				id_conge=result.getString("id_conge");
				date_debut=new Date(result.getString("date_debut")) ;
				date_fin=new Date(result.getString("date_fin")) ;
				motif=result.getString("motif");
				paye=result.getBoolean("payer");
				
				Conge c =new Conge(id_conge,date_debut,date_fin,motif,paye);
				
				ArrayList<Conge> lc = new ArrayList<Conge>();
				lc.add(c);	
				e.setConge(lc);

			}
			else if(object.equals("Contrat")) {
				String id_char;
				String fonction;
				Date date_recrut;
				String secteur;
				
				id_char=result.getString("id_contrat");
				fonction=result.getString("fonction");
				date_recrut = new Date(result.getString("date_recrut")) ;
				secteur=result.getString("secteur");
				
				Contrat c1 = new Contrat (id_char,fonction,date_recrut,secteur);
				
				ArrayList<Contrat> lc = new ArrayList<Contrat>();
				lc.add(c1);	
				e.setContrat(lc);
			}
			
			else {
				System.out.println("Error, cette table est inexistante");
			}
			}
			stmt.close();
			
		}	
	 
public void Info(ArrayList<Employe> e) throws SQLException {
		//e.get(e.size() - 1).getId_employe();
		
		 
	//getemployeesInfo().get()
		 
		if (e.size() > 0) {
		searchAttribute(e.get(e.size() - 1).getId_employe(), "Salaire",e.get(e.size() - 1));
		searchAttribute(e.get(e.size() - 1).getId_employe(), "Absence",e.get(e.size() - 1));
		searchAttribute(e.get(e.size() - 1).getId_employe(), "Contrat",e.get(e.size() - 1));
		searchAttribute(e.get(e.size() - 1).getId_employe(),"Conge",e.get(e.size() - 1));
		 
		}
		else {
	        System.out.println("Error: ArrayList is empty.");
	    }
		 
		 
		 
		 
		 
		 
		  
	 }
	 
	 
	 
/**
 * Get a list of EmployeUs.
 *  
 * @return a list of EmployeUs
 */






	public ArrayList<String> getTypes() {
	return types;
}

public void setTypes(ArrayList<String> types) {
	this.types = types;
}

public Map<String, Integer> getCounts() {
	return counts;
}

public void setCounts(Map<String, Integer> counts) {
	this.counts = counts;
}

	public ArrayList<Conge> getConge() {
	return conge;
}



public void setConge(ArrayList<Conge> conge) {
	this.conge = conge;
}



	public ArrayList<Contrat> getContrat() {
		return contrat;
	}



	public void setContrat(ArrayList<Contrat> contrat) {
		this.contrat = contrat;
	}



	public ArrayList<Absence> getAbsence() {
		return absence;
	}



	public void setAbsence(ArrayList<Absence> absence) {
		this.absence = absence;
	}



	public Salaire getSalaire() {
		return salaire;
	}



	public void setSalaire(Salaire salaire) {
		this.salaire = salaire;
	}



	public ArrayList<Employe> getOldPerson() {
		return OldPerson;
	}



	public void setOldPerson(ArrayList<Employe> oldPerson) {
		OldPerson = oldPerson;
	}



	public ArrayList<Employe> getAbsencesEmploye() {
		return AbsencesEmploye;
	}



	public void setAbsencesEmploye(ArrayList<Employe> absencesEmploye) {
		AbsencesEmploye = absencesEmploye;
	}



	public ArrayList<Employe> getMaxSalaire() {
		return MaxSalaire;
	}



	public void setMaxSalaire(ArrayList<Employe> maxSalaire) {
		MaxSalaire = maxSalaire;
	}



	public void setDtf(FranceDataBaseConnect dtf) {
		this.dtf = dtf;
	}



	public ArrayList<Employe> getemployeesInfo() {
		return employeeInfo;
	}



	public void setemployeesInfo(ArrayList<Employe> employeeInfo) {
		employeeInfo = employeeInfo;
	}



	public ArrayList<Employe> getEmployeesInfo() {
		return employeeInfo;
	}



	public void setEmployeesInfo(ArrayList<Employe> employeesInfo) {
		this.employeeInfo = employeesInfo;
	}



	public ArrayList<Employe> getSup3000() {
		return sup3000;
	}



	public void setSup3000(ArrayList<Employe> sup3000) {
		this.sup3000 = sup3000;
	}



	



	public String[][] getAverageSalary() {
		return averageSalary;
	}



	public void setAverageSalary(String[][] averageSalary) {
		this.averageSalary = averageSalary;
	}



	public ArrayList<Employe> getOvertimeEmployees() {
		return overtimeEmployees;
	}



	public void setOvertimeEmployees(ArrayList<Employe> overtimeEmployees) {
		this.overtimeEmployees = overtimeEmployees;
	}



	public ArrayList<Employe> getSortEmployeesSalary() {
		return sortEmployeesSalary;
	}



	public void setSortEmployeesSalary(ArrayList<Employe> sortEmployeesSalary) {
		this.sortEmployeesSalary = sortEmployeesSalary;
	}



	public ArrayList<Employe> getEmployeesBonusSalary() {
		return EmployeesBonusSalary;
	}



	public void setEmployeesBonusSalary(ArrayList<Employe> employeesBonusSalary) {
		EmployeesBonusSalary = employeesBonusSalary;
	} 
	
	 

}


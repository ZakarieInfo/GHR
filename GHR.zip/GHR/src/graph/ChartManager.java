package graph;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.opencsv.exceptions.CsvValidationException;

import mediator.MediatorDAO;

/**
 * This class manages all instrument charts of the graphical tree, including : 1) pie chart for node type count 2) bar chart for node type count 3) curve
 * chart for tree height evolution during the visit.
 * 
 * This class works with {@link InstrumentVisitor} which feeds the necessary information asked by the charts.
 * 
 * @see InstrumentVisitor
 * @author Tianxiao.Liu@u-cergy.fr
 */
public class ChartManager {
	private HashMap<Character, Double> HF = new HashMap<Character, Double>();
	private HashMap<Character, Double> IV = new HashMap<Character, Double>();
	private HashMap<Character, Double> SM = new HashMap<Character, Double>();
	
	private String averageSalary[][]= new String[3][10];
	private ArrayList<Integer> heights = new ArrayList<Integer>();
	
	/**
	 * Initializes the manager, by creating null value for each node type.
	 */
	public ChartManager () {
		HF.put('H', 0.0);
		HF.put('F', 0.0);
		
		IV.put('I', 0.0);
		IV.put('V', 0.0);
		
		SM.put('1', 0.0);
		SM.put('2', 0.0);
		SM.put('3', 0.0);
		SM.put('4', 0.0);
		SM.put('5', 0.0);
	}
/*	public ChartManager () {
		nodeTypeCount.put('c', 0);
		nodeTypeCount.put('v', 0);
		nodeTypeCount.put('a', 0);
		nodeTypeCount.put('s', 0);
		nodeTypeCount.put('m', 0);
	}
*/
	/**
	 * Counts update for node types.
	 * 
	 * @param type the node type to count
	 * @throws SQLException 
	 * @throws CsvValidationException 
	 */
	
	public void HF(String country) throws SQLException, CsvValidationException {
		MediatorDAO mh = new MediatorDAO(country);
		MediatorDAO mf = new MediatorDAO(country);
		mh.chooseDataSource("8");
		mf.chooseDataSource("9");
		
		HF.put('H',mh.getMen());
		HF.put('F',mf.getWomen());
		
	}
	
	public void IV(String country) throws SQLException, CsvValidationException {
		MediatorDAO mi = new MediatorDAO(country);
		
		mi.chooseDataSource("14");
		/*DecimalFormat decimalFormat = new DecimalFormat("#0.00");
		String pourcentageStr =""+  mi.getHandicap()+"";
		Double handicap = Double.parseDouble(decimalFormat.format(Double.parseDouble(pourcentageStr.replace(",", "."))));
		
		System.out.println(handicap);*/
	
		IV.put('I',mi.getHandicap());
		IV.put('V',100-mi.getHandicap());
		}
	
	public void SM(String country) throws SQLException, CsvValidationException {
		MediatorDAO sm = new MediatorDAO(country);
		
		
		sm.chooseDataSource("12");
		
		
		
		SM.put('1',(double) sm.getMaxSalaire().get(0).getSalaire().getMontant_brut());
		SM.put('2', (double) sm.getMaxSalaire().get(1).getSalaire().getMontant_brut());
		SM.put('3', (double) sm.getMaxSalaire().get(2).getSalaire().getMontant_brut());
		SM.put('4', (double) sm.getMaxSalaire().get(3).getSalaire().getMontant_brut());
		SM.put('5', (double) sm.getMaxSalaire().get(4).getSalaire().getMontant_brut());
		
	}
	
	public void AS(String country) throws SQLException, CsvValidationException{
		MediatorDAO as = new MediatorDAO(country);
		as.chooseDataSource("3");
		averageSalary=as.getAverageSalary();
		

		
		
		
	} 
	/*public void IV(String coutry) {
		int count = nodeTypeCount.get(type);
		nodeTypeCount.put(type, count + 1);
	}
*/
	/**
	 * Adds step by step the evolution of the tree height.
	 * 
	 * @param height current tree height
	 */
	
	public void registerHeightByStep(int height) {
		heights.add(height);
	}
	
	
	public JFreeChart	HFGraph() {
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Homme: "+HF.get('H')+"%", HF.get('H'));
		dataset.setValue("Femme: "+HF.get('F')+"%", HF.get('F'));
		

		return ChartFactory.createPieChart("Réparition de la parité", dataset, true, true, false);
	}
	
	public JFreeChart	IVGraph() {
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Invalide: "+IV.get('I')+"%", IV.get('I'));
		dataset.setValue("Valide: "+IV.get('V')+"%", IV.get('V'));
		

		return ChartFactory.createPieChart("Réparition de employés valide et invalide", dataset, true, true, false);
	}
	
	
	public JFreeChart SMGraph() {
		
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		dataset.setValue(SM.get('1'),"1" , SM.get('1'));
		dataset.setValue(SM.get('2'),"2" , SM.get('1'));
		dataset.setValue(SM.get('3'), "3" ,SM.get('1'));
		dataset.setValue(SM.get('3'), "4",SM.get('1'));
		dataset.setValue(SM.get('4'), "5", SM.get('1'));

		return ChartFactory.createBarChart("TOP 5 des employés les mieux payés", "", "Salaire", dataset, PlotOrientation.HORIZONTAL, true, true, false);
	}
	
	public JFreeChart ASGraph() {
	    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	    int j = 0;

	    while (j < 10 && averageSalary[0][j] != null) {
	        dataset.setValue(Double.parseDouble(averageSalary[2][j]), averageSalary[0][j], averageSalary[1][j]);
	        j++;
	    }

	    return ChartFactory.createBarChart("Pour chaque secteur de travail, les fonctions et les salaires moyens", "", "Secteur", dataset, PlotOrientation.VERTICAL, true, true, false);
	}
	/*
	public JFreeChart getTypeCountPie() {
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Constant", nodeTypeCount.get('c'));
		dataset.setValue("Variable", nodeTypeCount.get('v'));
		dataset.setValue("Addition", nodeTypeCount.get('a'));
		dataset.setValue("Subtraction", nodeTypeCount.get('s'));
		dataset.setValue("Multiplication", nodeTypeCount.get('m'));

		return ChartFactory.createPieChart("", dataset, true, true, false);
	}

	
	public JFreeChart getTypeCountBar() {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		dataset.setValue(nodeTypeCount.get('c'), "series", "Constant");
		dataset.setValue(nodeTypeCount.get('v'), "series", "Variable");
		dataset.setValue(nodeTypeCount.get('a'), "series", "Addition");
		dataset.setValue(nodeTypeCount.get('s'), "series", "Subtraction");
		dataset.setValue(nodeTypeCount.get('m'), "series", "Multiplication");

		return ChartFactory.createBarChart("", "Node type", "Count", dataset, PlotOrientation.VERTICAL, true, true, false);
	}

	
	public JFreeChart getHeightEvolutionChart() {
		XYSeries serie = new XYSeries("Height Evolution");
		for (int index = 0; index < heights.size(); index++) {
			serie.add(index, heights.get(index));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(serie);

		return ChartFactory.createXYLineChart("", "Visit step", "Height", dataset, PlotOrientation.VERTICAL, true, true, false);
	}
*/
}

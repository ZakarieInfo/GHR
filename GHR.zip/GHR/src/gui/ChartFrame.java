package gui;

import javax.swing.JFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

public class ChartFrame extends JFrame {

    private JFreeChart chart;

    public ChartFrame(JFreeChart chart) {
        this.chart = chart;

        ChartPanel chartPanel = new ChartPanel(chart);
        setContentPane(chartPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setVisible(true);
    }

    public void updateChart(JFreeChart chart) {
        this.chart = chart;
        ChartPanel chartPanel = new ChartPanel(chart);
        setContentPane(chartPanel);
    }
}

package gui;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import com.opencsv.exceptions.CsvValidationException;

import data.Employe;
import graph.ChartManager;
import mediator.MediatorDAO;

public class Fenetre extends JFrame {
	
	
	private JRadioButton usaButton = new JRadioButton("USA");
	private JRadioButton chinaButton = new JRadioButton("China");
	private JRadioButton canadaButton = new JRadioButton("Canada");
	private JRadioButton franceButton = new JRadioButton("France");
	private JRadioButton AllButton = new JRadioButton("All");
	JButton clearButton = new JButton("Clear");
	
	
    public Fenetre() {
    	super("Ma fenêtre");
    	
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
       // Création du menu
        JMenuBar menuBar = new JMenuBar();
        JMenu Liste = new JMenu("Liste");
        JMenu Graphique = new JMenu("Graphique");
        JMenuItem INFO = new JMenuItem("Informations sur l'employe");
        JMenuItem SALARY_SUP_3000 = new JMenuItem("La liste des employés qui ont un salaire >3000 euro net");
        JMenuItem OVERTIME_EMPLOYEES = new JMenuItem("La liste des employés qui ont fait des heures supplémentaires");
        JMenuItem SORT_EMPLOYEES_SALARY = new JMenuItem("Le tri des employé du plus payé au moins payé dans toute les entreprises");
        JMenuItem EMPLOYEES_BONUS_SALARY = new JMenuItem("La liste des employés qui ont eu un bonus sur leur salaires");
        JMenuItem EMPLOYE_OVER_60 = new JMenuItem("les employes qui ont plus de 60 ans ");
        JMenuItem ABS_3DAY = new JMenuItem("les employes qui ont été  absent plus de  3 jours");
        
        JMenuItem AVERAGE_SALARY = new JMenuItem("Pour chaque secteur de travail, les fonctions et les salaires moyens");
        JMenuItem POURCENTAGE_HF = new JMenuItem("pourcentges des employes H/F");
        JMenuItem POURCENTAGE_IV = new JMenuItem("pourcentges des employes Invalide et valide");
        JMenuItem NUMBER_OVER_60 = new JMenuItem("le nombre des employes qui ont plus de 60 ans ");
        JMenuItem MAX_SALAIRE = new JMenuItem("Les salaire max de chaque entreprise ");
        Liste.add(INFO);
        Liste.add(SALARY_SUP_3000);
        Liste.add(OVERTIME_EMPLOYEES);
        Liste.add(SORT_EMPLOYEES_SALARY);
        Liste.add(EMPLOYEES_BONUS_SALARY);
        Liste.add(EMPLOYE_OVER_60);
        Liste.add(ABS_3DAY);
        
        
        Graphique.add(AVERAGE_SALARY);
        Graphique.add(POURCENTAGE_HF);
        Graphique.add(POURCENTAGE_IV);
        Graphique.add(NUMBER_OVER_60);
        Graphique.add(MAX_SALAIRE);
        menuBar.add(Liste);
        menuBar.add(Graphique);
        setJMenuBar(menuBar);

        
        
        
        // Création des panels
        JPanel panel1 = new JPanel();
        panel1.setBackground(Color.DARK_GRAY);
        panel1.setPreferredSize(new Dimension(1500, 50));
        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.WHITE);
        panel2.setPreferredSize(new Dimension(1500, 900));
        JPanel panel3 = new JPanel();
        
        
        panel3.setBackground(Color.GRAY);
        panel3.setPreferredSize(new Dimension(1500,300));
     // Ajout des panels à la fenêtre
        
     
        
        add(panel1, BorderLayout.NORTH);
        add(panel2, BorderLayout.CENTER);
        add(panel3, BorderLayout.SOUTH);
        
        
        ButtonGroup buttonGroup = new ButtonGroup();
        usaButton.setSelected(true);
        buttonGroup.add(usaButton);
        buttonGroup.add(chinaButton);
        buttonGroup.add(canadaButton);
        buttonGroup.add(franceButton);
        buttonGroup.add(AllButton);
        buttonGroup.add(clearButton);
        
        panel1.add(usaButton);
        panel1.add(chinaButton);
        panel1.add(canadaButton);
        panel1.add(franceButton);
        panel1.add(AllButton);
        panel1.add(clearButton);
        
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	panel3.removeAll();
            	panel3.repaint();
                            
            
            }
                        
             }
                
            );
            	

     // Ajout d'un écouteur d'événements pour le menu item 1
        INFO.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	panel2.removeAll();
            	panel2.revalidate();
            	MediatorDAO m = new MediatorDAO(country());
            	try {
					m.chooseDataSource("1");
					
					JLabel l = new JLabel(printRequest("1", m.getCountry()));
			      	l.setBackground(Color.WHITE);
			      
			      	panel3.add(l,BorderLayout.WEST);
			      	panel3.repaint();
			      	l.setOpaque(true);
				
            	} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	//System.out.println(m.getCountry());
            	//System.out.println(m.getEmployeList());
            	//System.out.println("res"+StringEmloye(m.getEmployeList()));
            	String[] employees = StringEmloye(m.getEmployeList()) ;
            	JList<String> list = new JList<String>(employees);
            	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            	list.addListSelectionListener(new ListSelectionListener(){
                    public void valueChanged(ListSelectionEvent event) {
                        if (!event.getValueIsAdjusting()) {
                            int index = list.getSelectedIndex();
                            if (index >= 0) {
                                String selectedItem = (String) list.getModel().getElementAt(index);
                                if(panel2.getComponentCount()>1) {
                                	panel2.remove(1);
                                }
                                
                                JLabel label = new JLabel();
                                label.setText(m.getEmployeList().get(index).toStringGui());
                                panel2.add(label,BorderLayout.WEST);
                            	panel2.revalidate();
                                // Faire des actions sur l'élément sélectionné
                                //System.out.println(m.getEmployeList().get(index).toStringGui());
                                
                            }
                        }
                    }
                }
            );
            	
            	//list.addListSelectionListener(new ListSelectionListener() );
            	JScrollPane scrollPane = new JScrollPane(list);
            	panel2.add(scrollPane);
            	panel2.repaint();
            }
        });
       SALARY_SUP_3000.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	panel2.removeAll();
            	panel2.revalidate();
            	MediatorDAO m = new MediatorDAO(country());
            	try {
					m.chooseDataSource("2");
					JLabel l = new JLabel(printRequest("2",m.getCountry()));
                    l.setBackground(Color.WHITE);
                    panel3.add(l,BorderLayout.WEST);
                    panel3.repaint();
                    l.setOpaque(true);
					panel3.repaint();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	//System.out.println(m.getCountry());
            	//System.out.println(m.getEmployeList());
            	//System.out.println("res"+StringEmloye(m.getEmployeList()));
            	String[] employees = StringEmloye(m.getSup3000()) ;
            	JList<String> list = new JList<String>(employees);
            	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            	list.addListSelectionListener(new ListSelectionListener(){
                    public void valueChanged(ListSelectionEvent event) {
                        if (!event.getValueIsAdjusting()) {
                            int index = list.getSelectedIndex();
                            if (index >= 0) {
                                String selectedItem = (String) list.getModel().getElementAt(index);
                                if(panel2.getComponentCount()>1) {
                                	panel2.remove(1);
                                }
                                
                                JLabel label = new JLabel();
                                label.setText(m.getSup3000().get(index).toStringGui());
                                panel2.add(label,BorderLayout.WEST);
                            	panel2.revalidate();
                                // Faire des actions sur l'élément sélectionné
                                //System.out.println(m.getEmployeList().get(index).toStringGui());
                                
                            }
                        }
                    }
                }
            );
            	
            	//list.addListSelectionListener(new ListSelectionListener() );
            	JScrollPane scrollPane = new JScrollPane(list);
            	panel2.add(scrollPane);
            	panel2.revalidate();
            }
        });
       
       SORT_EMPLOYEES_SALARY.addActionListener(new ActionListener() {
		
		
		public void actionPerformed(ActionEvent e) {
			
			panel2.removeAll();
			panel2.repaint();
           	MediatorDAO m = new MediatorDAO(country());
           	try {
					m.chooseDataSource("5");
					JLabel l = new JLabel(printRequest("5",m.getCountry()));
                    l.setBackground(Color.WHITE);
                    panel3.add(l,BorderLayout.WEST);
                    panel3.repaint();
                    l.setOpaque(true);
					panel3.repaint();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
           	String[] employees = StringEmloye(m.getSortEmployeesSalary()) ;
           	JList<String> list = new JList<String>(employees);
           	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
           	
           	list.addListSelectionListener(new ListSelectionListener() {
				
				
				public void valueChanged(ListSelectionEvent event) {
					// TODO Auto-generated method stub
					if (!event.getValueIsAdjusting()) {
                        int index = list.getSelectedIndex();
                        if (index >= 0) {
                            String selectedItem = (String) list.getModel().getElementAt(index);
                            if(panel2.getComponentCount()>1) {
                            	panel2.remove(1);
                            }
                            
                            JLabel label = new JLabel();
                            label.setText(m.getSortEmployeesSalary().get(index).toStringGui());
                            panel2.add(label,BorderLayout.WEST);
                        	panel2.revalidate();
                            // Faire des actions sur l'Ã©lÃ©ment sÃ©lectionnÃ©
                            //System.out.println(m.getEmployeList().get(index).toStringGui());
                            
                        }
                    }
				}
			});
           	JScrollPane scrollPane = new JScrollPane(list);
           	panel2.add(scrollPane);
           	panel2.revalidate();
           
		}
	});
       
       OVERTIME_EMPLOYEES.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
           	
           	panel2.removeAll();
           	panel2.repaint();
           	MediatorDAO m = new MediatorDAO(country());
           	try {
					m.chooseDataSource("4");
					JLabel l = new JLabel(printRequest("4",m.getCountry()));
                    l.setBackground(Color.WHITE);
                    panel3.add(l,BorderLayout.WEST);
                    panel3.repaint();
                    l.setOpaque(true);
					panel3.repaint();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
           	//System.out.println(m.getCountry());
           	//System.out.println(m.getEmployeList());
           	//System.out.println("res"+StringEmloye(m.getEmployeList()));
           	String[] employees = StringEmloye(m.getOvertimeEmployees()) ;
           	JList<String> list = new JList<String>(employees);
           	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
           	list.addListSelectionListener(new ListSelectionListener(){
                   public void valueChanged(ListSelectionEvent event) {
                       if (!event.getValueIsAdjusting()) {
                           int index = list.getSelectedIndex();
                           if (index >= 0) {
                               String selectedItem = (String) list.getModel().getElementAt(index);
                               if(panel2.getComponentCount()>1) {
                               	panel2.remove(1);
                               }
                               
                               JLabel label = new JLabel();
                               label.setText(m.getOvertimeEmployees().get(index).toStringGui());
                               panel2.add(label,BorderLayout.WEST);
                           	panel2.revalidate();
                               // Faire des actions sur l'Ã©lÃ©ment sÃ©lectionnÃ©
                               //System.out.println(m.getEmployeList().get(index).toStringGui());
                               
                           }
                       }
                   }
               }
           );
           	
           	//list.addListSelectionListener(new ListSelectionListener() );
           	JScrollPane scrollPane = new JScrollPane(list);
           	panel2.add(scrollPane);
           	panel2.revalidate();
           }
       });
       
      	EMPLOYEES_BONUS_SALARY.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	panel2.removeAll();
            	panel2.repaint();
            	MediatorDAO m = new MediatorDAO(country());
            	try {
 					m.chooseDataSource("6");
 					JLabel l = new JLabel(printRequest("6",m.getCountry()));
                    l.setBackground(Color.WHITE);
                    panel3.add(l,BorderLayout.WEST);
                    panel3.repaint();
                    l.setOpaque(true);
					panel3.repaint();
 				} catch (SQLException e1) {
 					// TODO Auto-generated catch block
 					e1.printStackTrace();
 				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	//System.out.println(m.getCountry());
            	//System.out.println(m.getEmployeList());
            	//System.out.println("res"+StringEmloye(m.getEmployeList()));
            	String[] employees = StringEmloye(m.getEmployeesBonusSalary()) ;
            	JList<String> list = new JList<String>(employees);
            	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            	list.addListSelectionListener(new ListSelectionListener(){
                    public void valueChanged(ListSelectionEvent event) {
                        if (!event.getValueIsAdjusting()) {
                            int index = list.getSelectedIndex();
                            if (index >= 0) {
                                String selectedItem = (String) list.getModel().getElementAt(index);
                                if(panel2.getComponentCount()>1) {
                                	panel2.remove(1);
                                }
                                
                                JLabel label = new JLabel();
                                label.setText(m.getEmployeesBonusSalary().get(index).toStringGui());
                                panel2.add(label,BorderLayout.WEST);
                            	panel2.revalidate();
                                // Faire des actions sur l'Ã©lÃ©ment sÃ©lectionnÃ©
                                //System.out.println(m.getEmployeList().get(index).toStringGui());
                                
                            }
                        }
                    }
                }
            );
       	
       	
       	//list.addListSelectionListener(new ListSelectionListener() );
       	JScrollPane scrollPane = new JScrollPane(list);
       	panel2.add(scrollPane);
       	panel2.revalidate();
       }
   });
      	EMPLOYE_OVER_60.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	panel2.removeAll();
            	panel2.repaint();
            	MediatorDAO m = new MediatorDAO(country());
            	
            	try {
 					m.chooseDataSource("10");
 					JLabel l = new JLabel(printRequest("10",m.getCountry()));
                    l.setBackground(Color.WHITE);
                    panel3.add(l,BorderLayout.WEST);
                    panel3.repaint();
                    l.setOpaque(true);
					panel3.repaint();
 				} catch (SQLException e1) {
 					// TODO Auto-generated catch block
 					e1.printStackTrace();
 				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	//System.out.println(m.getCountry());
            	//System.out.println(m.getEmployeList());
            	//System.out.println("res"+StringEmloye(m.getEmployeList()));
            	String[] employees = StringEmloye(m.getOldPerson()) ;
            	if (employees.length<=0) {
            		panel2.removeAll();
                	panel2.repaint();
            		JLabel list = new JLabel("Aucun employé à afficher");
            		JScrollPane scrollPane = new JScrollPane(list);
             	   panel2.add(scrollPane);
             	 	panel2.revalidate();
                }  else {
            	JList<String> list = new JList<String>(employees);
            	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            	list.addListSelectionListener(new ListSelectionListener(){
                    public void valueChanged(ListSelectionEvent event) {
                        if (!event.getValueIsAdjusting()) {
                            int index = list.getSelectedIndex();
                            if (index >= 0) {
                                String selectedItem = (String) list.getModel().getElementAt(index);
                                if(panel2.getComponentCount()>1) {
                                	panel2.remove(1);
                                }
                                
                                JLabel label = new JLabel();
                                label.setText(m.getOldPerson().get(index).toStringGui());
                                panel2.add(label,BorderLayout.WEST);
                            	panel2.revalidate();
                                // Faire des actions sur l'Ã©lÃ©ment sÃ©lectionnÃ©
                                //System.out.println(m.getEmployeList().get(index).toStringGui());
                                
                            }
                        }
                    }
                }
            );
       	
       	
       	//list.addListSelectionListener(new ListSelectionListener() );
       	JScrollPane scrollPane = new JScrollPane(list);
       	
       	panel2.add(scrollPane);
       	panel2.revalidate();}
       }
   });
      	ABS_3DAY.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            	panel2.removeAll();
            	panel2.repaint();
            	MediatorDAO m = new MediatorDAO(country());
            	try {
 					m.chooseDataSource("13");
 					JLabel l = new JLabel(printRequest("13",m.getCountry()));
                    l.setBackground(Color.WHITE);
                    panel3.add(l,BorderLayout.WEST);
                    panel3.repaint();
                    l.setOpaque(true);
					panel3.repaint();
 					
 				} catch (SQLException e1) {
 					// TODO Auto-generated catch block
 					e1.printStackTrace();
 				}
            	//System.out.println(m.getCountry());
            	//System.out.println(m.getEmployeList());
            	//System.out.println("res"+StringEmloye(m.getEmployeList()));
 catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	
            	String[] employees = StringEmloye(m.getAbsencesEmploye()) ;
            	
            	if (employees.length<=0) {
            		panel2.removeAll();
                	panel2.repaint();
            		JLabel list = new JLabel("Aucun employé à afficher");
            		JScrollPane scrollPane = new JScrollPane(list);
             	   panel2.add(scrollPane);
             	 	panel2.revalidate();
                }  
                else {
                	panel2.removeAll();
                	panel2.repaint();
                	JList<String> list = new JList<String>(employees);
                	list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                	list.addListSelectionListener(new ListSelectionListener(){
                        public void valueChanged(ListSelectionEvent event) {
                            if (!event.getValueIsAdjusting()) {
                                int index = list.getSelectedIndex();
                                if (index >= 0) {
                                    String selectedItem = (String) list.getModel().getElementAt(index);
                                    if(panel2.getComponentCount()>1) {
                                    	panel2.remove(1);
                                    }
                                    
                                    JLabel label = new JLabel();
                                    label.setText(m.getAbsencesEmploye().get(index).toStringGui());
                                    panel2.add(label,BorderLayout.WEST);
                                	panel2.revalidate();
                                    // Faire des actions sur l'Ã©lÃ©ment sÃ©lectionnÃ©
                                    //System.out.println(m.getEmployeList().get(index).toStringGui());
                                    
                                }
                            }
                        }
                    }
                );
                	JScrollPane scrollPane = new JScrollPane(list);
             	   panel2.add(scrollPane);
             	 	panel2.revalidate();
                }
            	
    	   
	
       	
      
       }
   });
      	  	
      	POURCENTAGE_HF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	JLabel l = new JLabel(printRequest("8",country()));
                l.setBackground(Color.WHITE);
                panel3.add(l,BorderLayout.WEST);
                panel3.repaint();
                l.setOpaque(true);
				panel3.repaint();
            	
            	ChartManager HF = new ChartManager();
            	JFreeChart chart = HF.HFGraph();
            	panel2.removeAll();
            	panel2.repaint();
            	      	
            	ChartManager manager = new ChartManager();
                try {
                    manager.HF(country());
                    
                } catch (SQLException e1) {
                    e1.printStackTrace();
                } catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                ChartPanel chartPanel = new ChartPanel(manager.HFGraph());
               
                panel2.add(chartPanel, BorderLayout.CENTER);
                	
             	   //panel2.add();
             	 	panel2.revalidate();
                }
            	
    	   
	
       	
      
       
   });
      	POURCENTAGE_IV.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	JLabel l = new JLabel(printRequest("14",country()));
                l.setBackground(Color.WHITE);
                panel3.add(l,BorderLayout.WEST);
                panel3.repaint();
                l.setOpaque(true);
				panel3.repaint();
            	
            	ChartManager IV = new ChartManager();
            	JFreeChart chart = IV.IVGraph();
            	panel2.removeAll();
            	panel2.repaint();
            	      	
            	ChartManager manager = new ChartManager();
                try {
                    manager.IV(country());
                } catch (SQLException e1) {
                    e1.printStackTrace();
                } catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                ChartPanel chartPanel = new ChartPanel(manager.IVGraph());
                
                panel2.add(chartPanel, BorderLayout.CENTER);
                	
             	   //panel2.add();
             	 	panel2.revalidate();
                }
            	
    	   
	
       	
      
       
   });
      	MAX_SALAIRE.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	JLabel l = new JLabel(printRequest("12",country()));
                l.setBackground(Color.WHITE);
                panel3.add(l,BorderLayout.WEST);
                panel3.repaint();
                l.setOpaque(true);
				panel3.repaint();
            	MediatorDAO m = new MediatorDAO(country());
            	String txt ="<html>";
            	try {
					m.chooseDataSource("12");
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	
            	for (int i = 0; i <5 ; i++) {
					txt += i+1+". "+m.getMaxSalaire().get(i).getNom_employe()+" "+m.getMaxSalaire().get(i).getPrenom_employe()+"<br/>";
				}
            	txt+="<html>";
            	
            	JLabel lb = new JLabel();
            	lb.setText(txt);
            	
            	ChartManager SM = new ChartManager();
            	JFreeChart chart = SM.SMGraph();
            	panel2.removeAll();
            	panel2.repaint();
            	      	
            	ChartManager manager = new ChartManager();
                try {
                    manager.SM(country());
                } catch (SQLException e1) {
                    e1.printStackTrace();
                } catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                ChartPanel chartPanel = new ChartPanel(manager.SMGraph());
                
                panel2.add(chartPanel, BorderLayout.CENTER);
                	
             	 panel2.add(lb,BorderLayout.SOUTH);
             	 	panel2.revalidate();
                }
            	
    	   
	
       	
      
       
   });
      	AVERAGE_SALARY.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	JLabel l = new JLabel(printRequest("3",country()));
                l.setBackground(Color.WHITE);
                panel3.add(l,BorderLayout.WEST);
                panel3.repaint();
                l.setOpaque(true);
				panel3.repaint();
            	ChartManager AS = new ChartManager();
            	JFreeChart chart = AS.ASGraph();
            	panel2.removeAll();
            	panel2.repaint();
            	      	
            	ChartManager manager = new ChartManager();
            	
                try {
					manager.AS(country());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CsvValidationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                ChartPanel chartPanel = new ChartPanel(manager.ASGraph());
                
                panel2.add(chartPanel, BorderLayout.CENTER);
                	
             	   //panel2.add();
             	 	panel2.revalidate();
                }
            	
    	   
	
       	
      
       
   });

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        
    }
    public String country() {
    	if(usaButton.isSelected()) {
    		return "Us";
    	}
    	else if(franceButton.isSelected()) {
    		return "Fr";
    	}
    	else if(chinaButton.isSelected()) {
    		return "Ch";
    	}
    	else if(canadaButton.isSelected()) {
    		return "Ca";
    	}
    	else if(AllButton.isSelected()) {
    		return "All";
    	}
    	else {
    		return null;
    	}
    }
    
    public String[] StringEmloye(ArrayList<Employe> e) {
        String[] results = new String[e.size()];
        for (int i = 0; i < e.size(); i++) {
            results[i] = e.get(i).toString();
            		//"" + e.get(i).getNom_employe() + " " + e.get(i).getPrenom_employe() + " " + e.get(i).getSexe() + " " + e.get(i).getVille();
        }
        return results;
    }

    public static void main(String[] args) {
        Fenetre fenetre = new Fenetre();
    }
    
    public String printRequest(String number,String country) {
		String text="<html>";
    	
    	if(number.equals("1")){
    		text +="Informations sur l'employe<br/>";
    	}
    	else if(number.equals("2")){
    		text +="La liste des employés qui ont un salaire >3000 euro net<br/>";
    	}
    	else if(number.equals("3")){
    		text +="Les salaires moyens en fonction des secteurs et des fonctions<br/>";
    	}
    	else if(number.equals("4")){
    		text +="La liste des employés qui ont fait des heures supplémentaires<br/>";
    	}
    	else if(number.equals("5")){
    		text +="Le tri des employé du plus payé au moins payé dans toute les entreprises<br/>";
    	}
    	else if(number.equals("6")){
    		text +="La liste des employés qui ont eu un bonus sur leur salaires<br/>";
    	}
    	else if(number.equals("8")){
    		text +="Le pourcentage des hommes<br/>";
    	}
    	else if(number.equals("9")){
    		text +="le pourcentage des femmes<br/>";
    	}
    	else if(number.equals("10")){
    		text +="La liste des employés qui ont plus de 50 ans<br/>";
    	}else if(number.equals("12")){
    		text +="Le salaire maximum de chaque entreprise<br/>";
    	}else if(number.equals("13")){
    		text +="La liste des employés qui ont absenté plus de 3 jours consécutif<br/>";
    	}else if(number.equals("14")){
    		text +="Le pourcentage des handicapés<br/>";
    	}
    	if(country.equals("Us")) {
    		text +="Etats-Uni";
    	}
    	else if(country.equals("Fr")) {
    		text += "France";
    	}
    	else if(country.equals("Ch")) {
    		text += "Chine";
    	}
    	else if(country.equals("All")) {
    		text += "Tous les pays";
    	}
    	else if(country.equals("Ca")) {
    		text += "Canada";
    	}
    	text+="</html>";
    	
    	return text;
	
}
     
    }

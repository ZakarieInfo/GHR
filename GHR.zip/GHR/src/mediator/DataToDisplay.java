package mediator;

import java.util.ArrayList;

import javax.xml.bind.JAXBException;

import data.Employe;

/**
 * Interface which allows to write the name of all methods used to fill the data object which
 * will be exploited when the display of graphical elements.
 * 
 * @author Group D10
 * @version 1.0
 *
 */
public interface DataToDisplay {
	

	void employeesInfo();
	
}
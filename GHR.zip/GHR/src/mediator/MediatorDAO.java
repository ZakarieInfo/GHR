package mediator;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mysql.cj.xdevapi.Type;
import com.opencsv.exceptions.CsvValidationException;

import canada.CanadaDAO;
import china.ChinaDAO;
import config.Request;
import data.Employe;
import french.FrenchDAO;
import usa.UsaDataDAO;




public class MediatorDAO {
	private String country ;
	private ArrayList <Employe> EmployeList =  new ArrayList<Employe>();
	public ArrayList<String> types = new ArrayList<String>();
	private ArrayList <Employe> sup3000 =  new ArrayList<Employe>();
	private ArrayList <Employe> overtimeEmployees =  new ArrayList<Employe>();
	private ArrayList <Employe> sortEmployeesSalary =  new ArrayList<Employe>();
	private ArrayList <Employe> EmployeesBonusSalary =  new ArrayList<Employe>();
	private double women ;
    private double men;
	private double handicap;
    private ArrayList <Employe> MaxSalaire =  new ArrayList<Employe>();
	private ArrayList <Employe> OldPerson =  new ArrayList<Employe>();
	 private String averageSalary[][]= new String[3][10];
	 private ArrayList <Employe> AbsencesEmploye =  new ArrayList<Employe>();
	 
	
	
	public MediatorDAO() {
		super();
	}


	public MediatorDAO(String country) {
		super();
		this.country = country;
	}


	public void chooseDataSource(String request) throws SQLException, CsvValidationException {
		
		if(country == "All") {
			dataCanada(request);
			dataChina(request);
			dataFrench(request);
			dataUSA(request);
			//dataCanada(request);
		}
		else if(country.equals("Fr")) {
			
			dataFrench(request);
		}
		else if(country.equals("Us")) {
			
			dataUSA(request);
		}
		else if(country.equals("Ca")) {
			dataCanada(request);
		}
		else if(country.equals("Ch")) {
			dataChina(request);
		}
	}
	
	
	private void dataFrench(String request) throws SQLException {
		FrenchDAO fr = new FrenchDAO();
		if(request.equals(Request.INFO)) {
	
			fr.employeesInfo();
			EmployeList.addAll(fr.getemployeesInfo());
			
		}
		else if(request.equals(Request.CONGE_TYPE)) {
			fr.countCongesByType();
			setTypes(fr.getTypes());
		}
		else if(request.equals(Request.SALARY_SUP_3000)) 
		{
			FrenchDAO e = new FrenchDAO();
			e.Sup3000();
			sup3000.addAll(e.getSup3000());
		}
		else if(request.equals(Request.AVERAGE_SALARY)) 
		{
		
			fr.averageSalary();
			setAverageSalary(fr.getAverageSalary());
		}
		else if(request.equals(Request.OVERTIME_EMPLOYEES)) 
		{
			
			fr.overtimeEmployees();
			overtimeEmployees.addAll(fr.getOvertimeEmployees());
		}
		
	
		
		else if(request.equals(Request.SORT_EMPLOYEES_SALARY)) 
		{
			
			fr.sortEmployeesSalary();
			sortEmployeesSalary.addAll(fr.getSortEmployeesSalary());
		}
		else if(request.equals(Request.EMPLOYEES_BONUS_SALARY)) 
		{
			fr.EmployeesBonusSalary();
			EmployeesBonusSalary.addAll(fr.getEmployeesBonusSalary());
		}
		
		else if(request.equals(Request.POURCENTAGE_H)) {
			setMen(fr.pourcentageHommes());
			
			
		}
		else if(request.equals(Request.POURCENTAGE_F)) {
			setWomen(fr.pourcentageHommes());
			
			
		}
		else if(request.equals(Request.POURCENTAGE_HD)) {
			setHandicap(fr.PourcentageHandicapes());
			;
			
		}
		
		else if(request.equals(Request.EMPLOYE_OVER_60)) {
			fr.EmployeesOver60();
			//setOldPerson(fr.getOldPerson());
			OldPerson.addAll(fr.getOldPerson());	
			
		}
		
		else if(request.equals(Request.ABS_3DAY)) {
			fr.EmployesAbsentsPlusDeTroisJours();
			//setAbsencesEmploye(fr.getAbsencesEmploye());
			AbsencesEmploye.addAll(fr.getAbsencesEmploye());
			
		}
		
		else if(request.equals(Request.MAX_SALAIRE)) {
			fr.EmployesWithMaxSalaire();
		
			MaxSalaire.addAll(fr.getMaxSalaire());
			
		}
		
		
		
		
		
		
		
	}
	
	
	
	private void dataChina(String request) {
		ChinaDAO ch = new ChinaDAO();
		if(request.equals(Request.INFO)) {
			
			ch.employeesInfo();
			 EmployeList.addAll(ch.getEmploye());
		}
		else if(request.equals(Request.SALARY_SUP_3000)) 
		{
			
			ch.Sup3000();
			sup3000.addAll(ch.getSup3000());

		}
		else if(request.equals(Request.AVERAGE_SALARY)) 
		{
			
			ch.averageSalary();
			setAverageSalary(ch.getAverageSalary()); 
		}
		else if(request.equals(Request.OVERTIME_EMPLOYEES)) 
		{
			ch.overtimeEmployees();
			ch.overtimeEmployees();
			overtimeEmployees.addAll(ch.getOvertimeEmployees());
			
		}
		else if(request.equals(Request.EMPLOYEES_BONUS_SALARY)) 
		{
			ch.EmployeesBonusSalary();
			EmployeesBonusSalary.addAll(ch.getEmployeesBonusSalary());
			
		}
		else if(request.equals(Request.SORT_EMPLOYEES_SALARY)) 
		{
			ch.sortEmployeesSalary();
			sortEmployeesSalary.addAll(ch.getSortEmployeesSalary());
			
		}
		
		
		else if(request.equals(Request.CONGE_TYPE)) {
			ch.types();
			setTypes(ch.getTypes());		
		}
		
	
		else if(request.equals(Request.POURCENTAGE_H)) {
			ch.men();
			setMen(ch.getMen());
		
		
		}
		else if(request.equals(Request.POURCENTAGE_HD)) {
			ch.handicap();
			setMen(ch.getHandicap());
		
		}
		else if(request.equals(Request.POURCENTAGE_F)) {
			ch.women();
			setWomen(ch.getWomen());
		}
	else if(request.equals(Request.EMPLOYE_OVER_60)) {
		ch.OldPerson();
		//setOldPerson(fr.getOldPerson());
		OldPerson.addAll(ch.getOldPerson());
			
		}
		else if(request.equals(Request.NUMBER_OVER_60)){
			
		}
		
		else if(request.equals(Request.MAX_SALAIRE)){
			
			ch.MaxSalaire();
			MaxSalaire= ch.getMaxSalaire();
			
		}
		else if(request.equals(Request.ABS_3DAY)){
			ch.AbsencesEmploye();
			


			//AbsencesEmploye.addAll(ch.AbsencesEmploye());
	}

	
}

	
	private void dataUSA(String request) throws SQLException {
		UsaDataDAO us = new UsaDataDAO();
		if(request.equals(Request.INFO)) {
			us.employeesInfo();
			
			EmployeList.addAll(us.getemployeesInfo());
			
			
		}
		
		else if(request.equals(Request.CONGE_TYPE)) {
			us.countCongesByType();
			setTypes(us.getTypes());
		}
		else if(request.equals(Request.AVERAGE_SALARY)) {
			us.averageSalary();
			setAverageSalary(us.getAverageSalary());
			
			
		}
		else if(request.equals(Request.SALARY_SUP_3000)) {
			us.Sup3000();
			//setSup3000(us.getSup3000());	
			sup3000.addAll(us.getSup3000());
		}
		
		else if(request.equals(Request.OVERTIME_EMPLOYEES)) {
			us.overtimeEmployees();
			us.overtimeEmployees();
			overtimeEmployees.addAll(us.getOvertimeEmployees());	
			
		}
		
		else if(request.equals(Request.SORT_EMPLOYEES_SALARY)) {
			us.sortEmployeesSalary();
			sortEmployeesSalary.addAll(us.getSortEmployeesSalary());	
			
		}
		
		else if(request.equals(Request.EMPLOYEES_BONUS_SALARY)) {
			us.EmployeesBonusSalary();
			EmployeesBonusSalary.addAll(us.getEmployeesBonusSalary());
			
		}
		
		else if(request.equals(Request.POURCENTAGE_H)) {
			setMen(us.pourcentageHommes());
		}
		else if(request.equals(Request.POURCENTAGE_F)) {
			setWomen(us.pourcentageHommes());
			
		}
		else if(request.equals(Request.POURCENTAGE_HD)) {
			setHandicap(us.PourcentageHandicapes());
			
			
		}
		
		else if(request.equals(Request.EMPLOYE_OVER_60)) {
			us.EmployeesOver60();
			//setOldPerson(fr.getOldPerson());
			OldPerson.addAll(us.getOldPerson());	
			
		}
		
		else if(request.equals(Request.ABS_3DAY)) {
			us.EmployesAbsentsPlusDeTroisJours();
			
			AbsencesEmploye.addAll(us.getAbsencesEmploye());
			
		}
		
		else if(request.equals(Request.MAX_SALAIRE)) {
			us.EmployesWithMaxSalaire();
			MaxSalaire.addAll(us.getMaxSalaire());
			
		}
		
		
		
		
		
		
	}
	
	private void dataCanada(String request) throws CsvValidationException {
		CanadaDAO ca = new CanadaDAO();
		if(request.equals(Request.INFO)) {
			
			ca.employeesInfo();
			 EmployeList.addAll(ca.getEmployeList());
		}
		else if(request.equals(Request.SALARY_SUP_3000)) 
		{
			
			ca.Sup3000();
			sup3000.addAll(ca.getSup3000());

		}
		else if(request.equals(Request.AVERAGE_SALARY)) 
		{
			
			ca.averageSalary();
			setAverageSalary(ca.getAverageSalary()); 
		}
		else if(request.equals(Request.OVERTIME_EMPLOYEES)) 
		{
			
			ca.overtimeEmployees();
			overtimeEmployees.addAll(ca.getOvertimeEmployees());
			
		}
		else if(request.equals(Request.EMPLOYEES_BONUS_SALARY)) 
		{
			ca.EmployeesBonusSalary();
			EmployeesBonusSalary.addAll(ca.getEmployeesBonusSalary());
			
		}
		else if(request.equals(Request.SORT_EMPLOYEES_SALARY)) 
		{
			ca.sortEmployeesSalary();
			sortEmployeesSalary.addAll(ca.getSortEmployeesSalary());
			
		}
		
		
		else if(request.equals(Request.CONGE_TYPE)) {
			ca.types();
			setTypes(ca.getTypes());		
		}
		
	
		else if(request.equals(Request.POURCENTAGE_H)) {
			ca.men();
			setMen(ca.getMen());
		
		
		}
		else if(request.equals(Request.POURCENTAGE_HD)) {
			ca.handicap();
			setMen(ca.getHandicap());
		
		}
		else if(request.equals(Request.POURCENTAGE_F)) {
			ca.women();
			setWomen(ca.getWomen());
		}
	else if(request.equals(Request.EMPLOYE_OVER_60)) {
		ca.OldPerson();
		//setOldPerson(fr.getOldPerson());
		OldPerson.addAll(ca.getOldPerson());
			
		}
		else if(request.equals(Request.NUMBER_OVER_60)){
			
		}
		
		else if(request.equals(Request.MAX_SALAIRE)){
			
			ca.MaxSalaire();
			MaxSalaire= ca.getMaxSalaire();
			
		}
		else if(request.equals(Request.ABS_3DAY)){
			ca.AbsencesEmploye();
			


			//AbsencesEmploye.addAll(ca.AbsencesEmploye());
	}

		
	}


	
	
	public ArrayList<Employe> getEmployeList() {
		return EmployeList;
	}


	public void setEmployeList(ArrayList<Employe> employeList) {
		EmployeList = employeList;
	}


	public double getWomen() {
		return women;
	}


	public void setWomen(double women) {
		this.women = women;
	}


	public double getMen() {
		return men;
	}


	public void setMen(double men) {
		this.men = men;
	}


	public double getHandicap() {
		return handicap;
	}


	public void setHandicap(double handicap) {
		this.handicap = handicap;
	}


	public ArrayList<Employe> getMaxSalaire() {
		return MaxSalaire;
	}


	public void setMaxSalaire(ArrayList<Employe> maxSalaire) {
		MaxSalaire = maxSalaire;
	}


	public ArrayList<Employe> getOldPerson() {
		return OldPerson;
	}


	public void setOldPerson(ArrayList<Employe> oldPerson) {
		OldPerson = oldPerson;
	}

	
	public String[][] getAverageSalary() {
		return averageSalary;
	}


	public void setAverageSalary(String[][] averageSalary) {
		this.averageSalary = averageSalary;
	}


	public ArrayList<Employe> getAbsencesEmploye() {
		return AbsencesEmploye;
	}


	public void setAbsencesEmploye(ArrayList<Employe> absencesEmploye) {
		AbsencesEmploye = absencesEmploye;
	}


	public ArrayList<Employe> getEmployeesBonusSalary() {
		return EmployeesBonusSalary;
	}


	public void setEmployeesBonusSalary(ArrayList<Employe> employeesBonusSalary) {
		EmployeesBonusSalary = employeesBonusSalary;
	}


	public ArrayList<Employe> getSortEmployeesSalary() {
		return sortEmployeesSalary;
	}


	public void setSortEmployeesSalary(ArrayList<Employe> sortEmployeesSalary) {
		this.sortEmployeesSalary = sortEmployeesSalary;
	}


	public ArrayList<Employe> getOvertimeEmployees() {
		return overtimeEmployees;
	}


	public void setOvertimeEmployees(ArrayList<Employe> overtimeEmployees) {
		this.overtimeEmployees = overtimeEmployees;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public ArrayList<String> getTypes() {
		return types;
	}


	public void setTypes(ArrayList<String> types) {
		this.types = types;
	}


	public ArrayList<Employe> getSup3000() {
		return sup3000;
	}


	public void setSup3000(ArrayList<Employe> sup3000) {
		this.sup3000 = sup3000;
	}
	
	
	
	 
}

package test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.bind.JAXBException;

import com.opencsv.exceptions.CsvValidationException;

import bdconnection.FranceDataBaseConnect;
import canada.CanadaDAO;
import china.ChinaDAO;
import config.Request;
import data.Employe;
import french.FrenchDAO;
import gui.Fenetre;
import mediator.MediatorDAO;
import usa.UsaDataDAO;



public class test {

	public static void main(String[] args) throws JAXBException, SQLException, CsvValidationException {
		// TODO Auto-generated method stub
		
	/*GlobalMediator g = new GlobalMediator("All");
		g.chooseDataSource("1");
	*/
		  /*
			 FrenchDataDisplay f = new FrenchDataDisplay();
			 
				f.sortEmployeesSalary();
				
				for (int i = 0; i < f.getSortEmployeesSalary().size(); i++) {
					
					System.out.println(f.getSortEmployeesSalary().get(i).getNom_employe());
					System.out.println(f.getSortEmployeesSalary().get(i).getPrenom_employe());
					System.out.println(f.getSortEmployeesSalary().get(i).getSalaire().getMontant_brut());
					
				}
			*/
		
		//u.getTypes()
		
		/*
		MediatorDAO m = new MediatorDAO("Us");
		m.chooseDataSource("3");
		
		String[][] result = m.getAverageSalary();
		
		
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.println(result[i][j]+" ");
			}
			System.out.println("\t");
		}
		System.out.println(result[0].length);
		*/
		
		
 
			Fenetre gameMainGUI = new Fenetre();

			Thread gameThread = new Thread();
			gameThread.start(); 	

		/*
		MediatorDAO m = new MediatorDAO("Ca");
		m.chooseDataSource("10");
		System.out.println(m.getSup3000());
		*//*
		CanadaDAO c = new CanadaDAO();
		c.OldPerson();*/
		//System.out.println(c.getOldPerson());
		
	/*	
		FrenchDAO u = new FrenchDAO();
		
		System.out.println(u.pourcentageFemmes());
*/
	}

}
